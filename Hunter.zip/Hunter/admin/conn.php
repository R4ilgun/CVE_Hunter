<?php

$conn = mysqli_connect('localhost','root','root','cve');
if(!$conn){
    echo "Database connect error!";
}

?>
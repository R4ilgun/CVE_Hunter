<?php

function logout(){
   session_start();
   header('Content-type:text/html;charset=utf-8');
   if(isset($_SESSION['login_flag']) && $_SESSION['login_flag']===true){
       session_unset();
       session_destroy();
       echo "<script type='text/javascript'>alert('Logout successfully');location='../index.php';</script>";
   }else{
       echo "<script type='text/javascript'>alert('Logout failed');location='../index.php';</script>";
   }
}

logout();

?>

<?php

include("./conn.php");
include("./login_check.php");

?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>CVE Hunter</title>
  <link rel="stylesheet" href="css/layui.css" id="layui">
  <link rel="stylesheet" href="css/theme/default.css" id="theme">
  <link rel="stylesheet" href="css/kitadmin.css" id="kitadmin">

</head>


<body class="layui-layout-body kit-theme-default">
  <div class="layui-layout layui-layout-admin">
    <!-- header -->
    <div class="layui-header">
      <div class="layui-logo">
        <div class="layui-logo-toggle" kit-toggle="side" data-toggle="on">
          <i class="layui-icon">&#xe65a;</i>
        </div>
        <div class="layui-logo-brand">
          <a href="#/">CVE Hunter</a>
        </div>
      </div>
      <div class="layui-layout-left">
        <!-- <div class="kit-search">
          <form action="/">
            <input type="text" name="keyword" class="kit-search-input" placeholder="关键字..." />
            <button class="kit-search-btn" title="搜索" type="submit">
              <i class="layui-icon">&#xe615;</i>
            </button>
          </form>
        </div> -->
      </div>
      <div class="layui-layout-right">
        <ul class="kit-nav" lay-filter="header_right">
          <li class="kit-item" kit-target="help">
            <a href="javascript:;">
              <i class="layui-icon">&#xe607;</i>
              <span>Help</span>
            </a>
          </li>
          <li class="kit-item">
            <a href="javascript:;">
              <span>
                Railgun
              </span>
            </a>
            <ul class="kit-nav-child kit-nav-right">
              <li class="kit-item">
                <a href="#/user/my">
                  <i class="layui-icon">&#xe612;</i>
                  <span>User Center</span>
                </a>
              </li>
              <li class="kit-item" kit-target="setting">
                <a href="javascript:;">
                  <i class="layui-icon">&#xe614;</i>
                  <span>Settings</span>
                </a>
              </li>
              <li class="kit-nav-line"></li>
              <li class="kit-item">
                <a href="logout.php">
                  <i class="layui-icon">&#x1006;</i>
                  <span>Logout</span>
                </a>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
    <!-- silds -->
    <div class="layui-side" kit-side="true">
      <div class="layui-side-scroll">
        <div id="menu-box">
          <ul class="kit-menu">
            <li class="kit-menu-item">
              <a href="#/">
                <i class="layui-icon"></i>
                <span>Index</span>
              </a>
	    </li>
           <!-- 
            <li class="kit-menu-item layui-child">
              <a href="javascript:;">
                <i class="layui-icon"></i>
                <span>Layui Plugins</span>
              </a>
              <ul class="kit-menu-child layui-anim layui-anim-upbit">
                <li class="kit-menu-item">
                  <a href="javascript:;">
                    <i class="layui-icon"></i>
                    <span>基本元素</span>
                  </a>
                  <ul class="kit-menu-child layui-anim layui-anim-upbit">
                    <li class="kit-menu-item">
                      <a href="#/layui/button">
                        <i class="layui-icon">&#xe62e;</i>
                        <span>按钮</span>
                      </a>
                    </li>
                  </ul>
                </li>
                <li class="kit-menu-item layui-show">
                  <a href="javascript:;">
                    <i class="layui-icon"></i>
                    <span>组件</span>
                  </a>
                  <ul class="kit-menu-child layui-anim layui-anim-upbit">
                    <li class="kit-menu-item">
                      <a href="#/layui/layer">
                        <i class="layui-icon">&#xe62e;</i>
                        <span>弹出层</span>
                      </a>
                    </li>
                    <li class="kit-menu-item">
                      <a href="#/layui/table">
                        <i class="layui-icon">&#xe62e;</i>
                        <span>数据表格</span>
                      </a>
                    </li>
                    <li class="kit-menu-item">
                      <a href="#/layui/laypage">
                        <i class="layui-icon">&#xe62e;</i>
                        <span>分页</span>
                      </a>
                    </li>
                  </ul>
                </li>
              </ul>
	    </li>
            -->
            <li class="kit-menu-item">
              <a href="#/cve/select">
                <i class="layui-icon"></i>
                <span>Select CVE</span>
              </a>
              
            </li>
            <li class="kit-menu-item">
              <a href="javascript:;" class="child">
                <i class="layui-icon"></i>
                <span>API Document</span>
              </a>
              <ul class="kit-menu-child layui-anim layui-anim-upbit">
                <li class="kit-menu-item">
                  <a href="#/docs/mockjs">
                    <i class="layui-icon"></i>
                    <span>拦截器(Mockjs)</span>
                  </a>
                </li>
                <li class="kit-menu-item">
                  <a href="#/docs/menu">
                    <i class="layui-icon"></i>
                    <span>左侧菜单(Menu)</span>
                  </a>
                </li>
                <li class="kit-menu-item">
                  <a href="#/docs/route">
                    <i class="layui-icon"></i>
                    <span>路由配置(Route)</span>
                  </a>
                </li>
                <li class="kit-menu-item">
                  <a href="#/docs/tabs">
                    <i class="layui-icon"></i>
                    <span>选项卡(Tabs)</span>
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- main -->
    <div class="layui-body" kit-body="true">
      <router-view></router-view>
    </div>
    <!-- footer -->
    <div class="layui-footer" kit-footer="true">
      2020 © Railgun CVE Hunter
      <div style="width:400px; height:400px;" class="load-container load1">
        <div class="loader">Loading...</div>
      </div>
    </div>
  </div>
  <script src="layui.js"></script>
  <script src="kitadmin.js"></script>
  <script src="mockjs-config.js"></script>

  <script src="lay/kit_modules/echarts.min.js"></script>
  <script>layui.use("admin");</script>

</body>

</html>

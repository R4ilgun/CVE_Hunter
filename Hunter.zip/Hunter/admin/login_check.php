<?php
    $login_flag = false;
    session_start();

    if (isset($_SESSION["login_flag"]) && $_SESSION["login_flag"] === true) {
        
    } 
    else {
        $_SESSION["login_flag"] = false;
        echo "<script type='text/javascript'>alert('Please login first');location='../index.php';</script>";
	
    }

?>

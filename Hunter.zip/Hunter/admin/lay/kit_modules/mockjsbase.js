
;
"use strict";
var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
function(t) {
    return typeof t
}: function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol": typeof t
};
layui.define(function(exports) {
    var py, qy;
    py = this,
    qy = function() {
        return function(t) {
            function e(r) {
                if (n[r]) return n[r].exports;
                var a = n[r] = {
                    exports: {},
                    id: r,
                    loaded: !1
                };
                return t[r].call(a.exports, a, a.exports, e),
                a.loaded = !0,
                a.exports
            }
            var n = {};
            return e.m = t,
            e.c = n,
            e.p = "",
            e(0)
        } ([function(t, e, n) {
            var r, a = n(1),
            o = n(3),
            i = n(5),
            u = n(20),
            l = n(23),
            s = n(25);
            "undefined" != typeof window && (r = n(27));
            var c = {
                Handler: a,
                Random: i,
                Util: o,
                XHR: r,
                RE: u,
                toJSONSchema: l,
                valid: s,
                heredoc: o.heredoc,
                setup: function(t) {
                    return r.setup(t)
                },
                _mocked: {},
                version: "1.0.1-beta3"
            };
            r && (r.Mock = c),
            c.mock = function(t, e, n) {
                return 1 === arguments.length ? a.gen(t) : (2 === arguments.length && (n = e, e = void 0), r && (window.XMLHttpRequest = r), c._mocked[t + (e || "")] = {
                    rurl: t,
                    rtype: e,
                    template: n
                },
                c)
            },
            t.exports = c
        },
        function(module, exports, __webpack_require__) {
            var Constant = __webpack_require__(2),
            Util = __webpack_require__(3),
            Parser = __webpack_require__(4),
            Random = __webpack_require__(5),
            RE = __webpack_require__(20),
            Handler = {
                extend: Util.extend,
                gen: function(t, e, n) {
                    e = void 0 == e ? "": e + "",
                    n = {
                        path: (n = n || {}).path || [Constant.GUID],
                        templatePath: n.templatePath || [Constant.GUID++],
                        currentContext: n.currentContext,
                        templateCurrentContext: n.templateCurrentContext || t,
                        root: n.root || n.currentContext,
                        templateRoot: n.templateRoot || n.templateCurrentContext || t
                    };
                    var r, a = Parser.parse(e),
                    o = Util.type(t);
                    return Handler[o] ? (r = Handler[o]({
                        type: o,
                        template: t,
                        name: e,
                        parsedName: e ? e.replace(Constant.RE_KEY, "$1") : e,
                        rule: a,
                        context: n
                    }), n.root || (n.root = r), r) : t
                }
            };
            Handler.extend({
                array: function(t) {
                    var e, n, r = [];
                    if (0 === t.template.length) return r;
                    if (t.rule.parameters) if (1 === t.rule.min && void 0 === t.rule.max) t.context.path.push(t.name),
                    t.context.templatePath.push(t.name),
                    r = Random.pick(Handler.gen(t.template, void 0, {
                        path: t.context.path,
                        templatePath: t.context.templatePath,
                        currentContext: r,
                        templateCurrentContext: t.template,
                        root: t.context.root || r,
                        templateRoot: t.context.templateRoot || t.template
                    })),
                    t.context.path.pop(),
                    t.context.templatePath.pop();
                    else if (t.rule.parameters[2]) t.template.__order_index = t.template.__order_index || 0,
                    t.context.path.push(t.name),
                    t.context.templatePath.push(t.name),
                    r = Handler.gen(t.template, void 0, {
                        path: t.context.path,
                        templatePath: t.context.templatePath,
                        currentContext: r,
                        templateCurrentContext: t.template,
                        root: t.context.root || r,
                        templateRoot: t.context.templateRoot || t.template
                    })[t.template.__order_index % t.template.length],
                    t.template.__order_index += +t.rule.parameters[2],
                    t.context.path.pop(),
                    t.context.templatePath.pop();
                    else for (e = 0; e < t.rule.count; e++) for (n = 0; n < t.template.length; n++) t.context.path.push(r.length),
                    t.context.templatePath.push(n),
                    r.push(Handler.gen(t.template[n], r.length, {
                        path: t.context.path,
                        templatePath: t.context.templatePath,
                        currentContext: r,
                        templateCurrentContext: t.template,
                        root: t.context.root || r,
                        templateRoot: t.context.templateRoot || t.template
                    })),
                    t.context.path.pop(),
                    t.context.templatePath.pop();
                    else for (e = 0; e < t.template.length; e++) t.context.path.push(e),
                    t.context.templatePath.push(e),
                    r.push(Handler.gen(t.template[e], e, {
                        path: t.context.path,
                        templatePath: t.context.templatePath,
                        currentContext: r,
                        templateCurrentContext: t.template,
                        root: t.context.root || r,
                        templateRoot: t.context.templateRoot || t.template
                    })),
                    t.context.path.pop(),
                    t.context.templatePath.pop();
                    return r
                },
                object: function(t) {
                    var e, n, r, a, o, i, u = {};
                    if (void 0 != t.rule.min) for (e = Util.keys(t.template), e = (e = Random.shuffle(e)).slice(0, t.rule.count), i = 0; i < e.length; i++) a = (r = e[i]).replace(Constant.RE_KEY, "$1"),
                    t.context.path.push(a),
                    t.context.templatePath.push(r),
                    u[a] = Handler.gen(t.template[r], r, {
                        path: t.context.path,
                        templatePath: t.context.templatePath,
                        currentContext: u,
                        templateCurrentContext: t.template,
                        root: t.context.root || u,
                        templateRoot: t.context.templateRoot || t.template
                    }),
                    t.context.path.pop(),
                    t.context.templatePath.pop();
                    else {
                        for (r in e = [], n = [], t.template)("function" == typeof t.template[r] ? n: e).push(r);
                        for (e = e.concat(n), i = 0; i < e.length; i++) a = (r = e[i]).replace(Constant.RE_KEY, "$1"),
                        t.context.path.push(a),
                        t.context.templatePath.push(r),
                        u[a] = Handler.gen(t.template[r], r, {
                            path: t.context.path,
                            templatePath: t.context.templatePath,
                            currentContext: u,
                            templateCurrentContext: t.template,
                            root: t.context.root || u,
                            templateRoot: t.context.templateRoot || t.template
                        }),
                        t.context.path.pop(),
                        t.context.templatePath.pop(),
                        (o = r.match(Constant.RE_KEY)) && o[2] && "number" === Util.type(t.template[r]) && (t.template[r] += parseInt(o[2], 10))
                    }
                    return u
                },
                number: function(t) {
                    var e, n;
                    if (t.rule.decimal) {
                        for (t.template += "", (n = t.template.split("."))[0] = t.rule.range ? t.rule.count: n[0], n[1] = (n[1] || "").slice(0, t.rule.dcount); n[1].length < t.rule.dcount;) n[1] += n[1].length < t.rule.dcount - 1 ? Random.character("number") : Random.character("123456789");
                        e = parseFloat(n.join("."), 10)
                    } else e = t.rule.range && !t.rule.parameters[2] ? t.rule.count: t.template;
                    return e
                },
                boolean: function(t) {
                    return t.rule.parameters ? Random.bool(t.rule.min, t.rule.max, t.template) : t.template
                },
                string: function(t) {
                    var e, n, r, a, o = "";
                    if (t.template.length) {
                        for (void 0 == t.rule.count && (o += t.template), e = 0; e < t.rule.count; e++) o += t.template;
                        for (n = o.match(Constant.RE_PLACEHOLDER) || [], e = 0; e < n.length; e++) if (r = n[e], /^\\/.test(r)) n.splice(e--, 1);
                        else {
                            if (a = Handler.placeholder(r, t.context.currentContext, t.context.templateCurrentContext, t), 1 === n.length && r === o && (void 0 === a ? "undefined": _typeof(a)) != (void 0 === o ? "undefined": _typeof(o))) {
                                o = a;
                                break
                            }
                            o = o.replace(r, a)
                        }
                    } else o = t.rule.range ? Random.string(t.rule.count) : t.template;
                    return o
                },
                function: function(t) {
                    return t.template.call(t.context.currentContext, t)
                },
                regexp: function(t) {
                    var e = "";
                    void 0 == t.rule.count && (e += t.template.source);
                    for (var n = 0; n < t.rule.count; n++) e += t.template.source;
                    return RE.Handler.gen(RE.Parser.parse(e))
                }
            }),
            Handler.extend({
                _all: function() {
                    var t = {};
                    for (var e in Random) t[e.toLowerCase()] = e;
                    return t
                },
                placeholder: function placeholder(_placeholder, obj, templateContext, options) {
                    Constant.RE_PLACEHOLDER.exec("");
                    var parts = Constant.RE_PLACEHOLDER.exec(_placeholder),
                    key = parts && parts[1],
                    lkey = key && key.toLowerCase(),
                    okey = this._all()[lkey],
                    params = parts && parts[2] || "",
                    pathParts = this.splitPathToArray(key);
                    try {
                        params = eval("(function(){ return [].splice.call(arguments, 0 ) })(" + params + ")")
                    } catch(t) {
                        params = parts[2].split(/,\s*/)
                    }
                    if (obj && key in obj) return obj[key];
                    if ("/" === key.charAt(0) || pathParts.length > 1) return this.getValueByKeyPath(key, options);
                    if (templateContext && "object" == (void 0 === templateContext ? "undefined": _typeof(templateContext)) && key in templateContext && _placeholder !== templateContext[key]) return templateContext[key] = Handler.gen(templateContext[key], key, {
                        currentContext: obj,
                        templateCurrentContext: templateContext
                    }),
                    templateContext[key];
                    if (! (key in Random || lkey in Random || okey in Random)) return _placeholder;
                    for (var i = 0; i < params.length; i++) Constant.RE_PLACEHOLDER.exec(""),
                    Constant.RE_PLACEHOLDER.test(params[i]) && (params[i] = Handler.placeholder(params[i], obj, templateContext, options));
                    var handle = Random[key] || Random[lkey] || Random[okey];
                    switch (Util.type(handle)) {
                    case "array":
                        return Random.pick(handle);
                    case "function":
                        handle.options = options;
                        var re = handle.apply(Random, params);
                        return void 0 === re && (re = ""),
                        delete handle.options,
                        re
                    }
                },
                getValueByKeyPath: function(t, e) {
                    var n = t,
                    r = this.splitPathToArray(t),
                    a = [];
                    "/" === t.charAt(0) ? a = [e.context.path[0]].concat(this.normalizePath(r)) : r.length > 1 && ((a = e.context.path.slice(0)).pop(), a = this.normalizePath(a.concat(r))),
                    t = r[r.length - 1];
                    for (var o = e.context.root,
                    i = e.context.templateRoot,
                    u = 1; u < a.length - 1; u++) o = o[a[u]],
                    i = i[a[u]];
                    return o && t in o ? o[t] : i && "object" == (void 0 === i ? "undefined": _typeof(i)) && t in i && n !== i[t] ? (i[t] = Handler.gen(i[t], t, {
                        currentContext: o,
                        templateCurrentContext: i
                    }), i[t]) : void 0
                },
                normalizePath: function(t) {
                    for (var e = [], n = 0; n < t.length; n++) switch (t[n]) {
                    case "..":
                        e.pop();
                        break;
                    case ".":
                        break;
                    default:
                        e.push(t[n])
                    }
                    return e
                },
                splitPathToArray: function(t) {
                    var e = t.split(/\/+/);
                    return e[e.length - 1] || (e = e.slice(0, -1)),
                    e[0] || (e = e.slice(1)),
                    e
                }
            }),
            module.exports = Handler
        },
        function(t, e) {
            t.exports = {
                GUID: 1,
                RE_KEY: /(.+)\|(?:\+(\d+)|([\+\-]?\d+-?[\+\-]?\d*)?(?:\.(\d+-?\d*))?)/,
                RE_RANGE: /([\+\-]?\d+)-?([\+\-]?\d+)?/,
                RE_PLACEHOLDER: /\\*@([^@#%&()\?\s]+)(?:\((.*?)\))?/g
            }
        },
        function(t, e) {
            var n = {
                extend: function() {
                    var t, e, r, a, o, i = arguments[0] || {},
                    u = 1,
                    l = arguments.length;
                    for (1 === l && (i = this, u = 0); l > u; u++) if (t = arguments[u]) for (e in t) r = i[e],
                    i !== (a = t[e]) && void 0 !== a && (n.isArray(a) || n.isObject(a) ? (n.isArray(a) && (o = r && n.isArray(r) ? r: []), n.isObject(a) && (o = r && n.isObject(r) ? r: {}), i[e] = n.extend(o, a)) : i[e] = a);
                    return i
                },
                each: function(t, e, n) {
                    var r, a;
                    if ("number" === this.type(t)) for (r = 0; t > r; r++) e(r, r);
                    else if (t.length === +t.length) for (r = 0; r < t.length && !1 !== e.call(n, t[r], r, t); r++);
                    else for (a in t) if (!1 === e.call(n, t[a], a, t)) break
                },
                type: function(t) {
                    return null === t || void 0 === t ? String(t) : Object.prototype.toString.call(t).match(/\[object (\w+)\]/)[1].toLowerCase()
                }
            };
            n.each("String Object Array RegExp Function".split(" "),
            function(t) {
                n["is" + t] = function(e) {
                    return n.type(e) === t.toLowerCase()
                }
            }),
            n.isObjectOrArray = function(t) {
                return n.isObject(t) || n.isArray(t)
            },
            n.isNumeric = function(t) {
                return ! isNaN(parseFloat(t)) && isFinite(t)
            },
            n.keys = function(t) {
                var e = [];
                for (var n in t) t.hasOwnProperty(n) && e.push(n);
                return e
            },
            n.values = function(t) {
                var e = [];
                for (var n in t) t.hasOwnProperty(n) && e.push(t[n]);
                return e
            },
            n.heredoc = function(t) {
                return t.toString().replace(/^[^\/]+\/\*!?/, "").replace(/\*\/[^\/]+$/, "").replace(/^[\s\xA0]+/, "").replace(/[\s\xA0]+$/, "")
            },
            n.noop = function() {},
            t.exports = n
        },
        function(t, e, n) {
            var r = n(2),
            a = n(5);
            t.exports = {
                parse: function(t) {
                    var e = ((t = void 0 == t ? "": t + "") || "").match(r.RE_KEY),
                    n = e && e[3] && e[3].match(r.RE_RANGE),
                    o = n && n[1] && parseInt(n[1], 10),
                    i = n && n[2] && parseInt(n[2], 10),
                    u = n ? n[2] ? a.integer(o, i) : parseInt(n[1], 10) : void 0,
                    l = e && e[4] && e[4].match(r.RE_RANGE),
                    s = l && l[1] && parseInt(l[1], 10),
                    c = l && l[2] && parseInt(l[2], 10),
                    h = {
                        parameters: e,
                        range: n,
                        min: o,
                        max: i,
                        count: u,
                        decimal: l,
                        dmin: s,
                        dmax: c,
                        dcount: l ? !l[2] && parseInt(l[1], 10) || a.integer(s, c) : void 0
                    };
                    for (var p in h) if (void 0 != h[p]) return h;
                    return {}
                }
            }
        },
        function(t, e, n) {
            var r = {
                extend: n(3).extend
            };
            r.extend(n(6)),
            r.extend(n(7)),
            r.extend(n(8)),
            r.extend(n(10)),
            r.extend(n(13)),
            r.extend(n(15)),
            r.extend(n(16)),
            r.extend(n(17)),
            r.extend(n(14)),
            r.extend(n(19)),
            t.exports = r
        },
        function(t, e) {
            t.exports = {
                boolean: function(t, e, n) {
                    return void 0 !== n ? (t = void 0 === t || isNaN(t) ? 1 : parseInt(t, 10), e = void 0 === e || isNaN(e) ? 1 : parseInt(e, 10), Math.random() > 1 / (t + e) * t ? !n: n) : Math.random() >= .5
                },
                bool: function(t, e, n) {
                    return this.boolean(t, e, n)
                },
                natural: function(t, e) {
                    return t = void 0 !== t ? parseInt(t, 10) : 0,
                    e = void 0 !== e ? parseInt(e, 10) : 9007199254740992,
                    Math.round(Math.random() * (e - t)) + t
                },
                integer: function(t, e) {
                    return t = void 0 !== t ? parseInt(t, 10) : -9007199254740992,
                    e = void 0 !== e ? parseInt(e, 10) : 9007199254740992,
                    Math.round(Math.random() * (e - t)) + t
                },
                int: function(t, e) {
                    return this.integer(t, e)
                },
                float: function(t, e, n, r) {
                    n = void 0 === n ? 0 : n,
                    n = Math.max(Math.min(n, 17), 0),
                    r = void 0 === r ? 17 : r,
                    r = Math.max(Math.min(r, 17), 0);
                    for (var a = this.integer(t, e) + ".", o = 0, i = this.natural(n, r); i > o; o++) a += i - 1 > o ? this.character("number") : this.character("123456789");
                    return parseFloat(a, 10)
                },
                character: function(t) {
                    var e = {
                        lower: "abcdefghijklmnopqrstuvwxyz",
                        upper: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                        number: "0123456789",
                        symbol: "!@#$%^&*()[]"
                    };
                    return e.alpha = e.lower + e.upper,
                    e.undefined = e.lower + e.upper + e.number + e.symbol,
                    (t = e[("" + t).toLowerCase()] || t).charAt(this.natural(0, t.length - 1))
                },
                char: function(t) {
                    return this.character(t)
                },
                string: function(t, e, n) {
                    var r;
                    switch (arguments.length) {
                    case 0:
                        r = this.natural(3, 7);
                        break;
                    case 1:
                        r = t,
                        t = void 0;
                        break;
                    case 2:
                        "string" == typeof arguments[0] ? r = e: (r = this.natural(t, e), t = void 0);
                        break;
                    case 3:
                        r = this.natural(e, n)
                    }
                    for (var a = "",
                    o = 0; r > o; o++) a += this.character(t);
                    return a
                },
                str: function() {
                    return this.string.apply(this, arguments)
                },
                range: function(t, e, n) {
                    arguments.length <= 1 && (e = t || 0, t = 0),
                    t = +t,
                    e = +e,
                    n = +(n = arguments[2] || 1);
                    for (var r = Math.max(Math.ceil((e - t) / n), 0), a = 0, o = new Array(r); r > a;) o[a++] = t,
                    t += n;
                    return o
                }
            }
        },
        function(t, e) {
            var n = {
                yyyy: "getFullYear",
                yy: function(t) {
                    return ("" + t.getFullYear()).slice(2)
                },
                y: "yy",
                MM: function(t) {
                    var e = t.getMonth() + 1;
                    return 10 > e ? "0" + e: e
                },
                M: function(t) {
                    return t.getMonth() + 1
                },
                dd: function(t) {
                    var e = t.getDate();
                    return 10 > e ? "0" + e: e
                },
                d: "getDate",
                HH: function(t) {
                    var e = t.getHours();
                    return 10 > e ? "0" + e: e
                },
                H: "getHours",
                hh: function(t) {
                    var e = t.getHours() % 12;
                    return 10 > e ? "0" + e: e
                },
                h: function(t) {
                    return t.getHours() % 12
                },
                mm: function(t) {
                    var e = t.getMinutes();
                    return 10 > e ? "0" + e: e
                },
                m: "getMinutes",
                ss: function(t) {
                    var e = t.getSeconds();
                    return 10 > e ? "0" + e: e
                },
                s: "getSeconds",
                SS: function(t) {
                    var e = t.getMilliseconds();
                    return 10 > e && "00" + e || 100 > e && "0" + e || e
                },
                S: "getMilliseconds",
                A: function(t) {
                    return t.getHours() < 12 ? "AM": "PM"
                },
                a: function(t) {
                    return t.getHours() < 12 ? "am": "pm"
                },
                T: "getTime"
            };
            t.exports = {
                _patternLetters: n,
                _rformat: new RegExp(function() {
                    var t = [];
                    for (var e in n) t.push(e);
                    return "(" + t.join("|") + ")"
                } (), "g"),
                _formatDate: function(t, e) {
                    return e.replace(this._rformat,
                    function e(r, a) {
                        return "function" == typeof n[a] ? n[a](t) : n[a] in n ? e(r, n[a]) : t[n[a]]()
                    })
                },
                _randomDate: function(t, e) {
                    return t = void 0 === t ? new Date(0) : t,
                    e = void 0 === e ? new Date: e,
                    new Date(Math.random() * (e.getTime() - t.getTime()))
                },
                date: function(t) {
                    return t = t || "yyyy-MM-dd",
                    this._formatDate(this._randomDate(), t)
                },
                time: function(t) {
                    return t = t || "HH:mm:ss",
                    this._formatDate(this._randomDate(), t)
                },
                datetime: function(t) {
                    return t = t || "yyyy-MM-dd HH:mm:ss",
                    this._formatDate(this._randomDate(), t)
                },
                now: function(t, e) {
                    1 === arguments.length && (/year|month|day|hour|minute|second|week/.test(t) || (e = t, t = "")),
                    t = (t || "").toLowerCase(),
                    e = e || "yyyy-MM-dd HH:mm:ss";
                    var n = new Date;
                    switch (t) {
                    case "year":
                        n.setMonth(0);
                    case "month":
                        n.setDate(1);
                    case "week":
                    case "day":
                        n.setHours(0);
                    case "hour":
                        n.setMinutes(0);
                    case "minute":
                        n.setSeconds(0);
                    case "second":
                        n.setMilliseconds(0)
                    }
                    switch (t) {
                    case "week":
                        n.setDate(n.getDate() - n.getDay())
                    }
                    return this._formatDate(n, e)
                }
            }
        },
        function(t, e, n) { (function(t) {
                t.exports = {
                    _adSize: ["300x250", "250x250", "240x400", "336x280", "180x150", "720x300", "468x60", "234x60", "88x31", "120x90", "120x60", "120x240", "125x125", "728x90", "160x600", "120x600", "300x600"],
                    _screenSize: ["320x200", "320x240", "640x480", "800x480", "800x480", "1024x600", "1024x768", "1280x800", "1440x900", "1920x1200", "2560x1600"],
                    _videoSize: ["720x480", "768x576", "1280x720", "1920x1080"],
                    image: function(t, e, n, r, a) {
                        return 4 === arguments.length && (a = r, r = void 0),
                        3 === arguments.length && (a = n, n = void 0),
                        t || (t = this.pick(this._adSize)),
                        e && ~e.indexOf("#") && (e = e.slice(1)),
                        n && ~n.indexOf("#") && (n = n.slice(1)),
                        "http://dummyimage.com/" + t + (e ? "/" + e: "") + (n ? "/" + n: "") + (r ? "." + r: "") + (a ? "&text=" + a: "")
                    },
                    img: function() {
                        return this.image.apply(this, arguments)
                    },
                    _brandColors: {
                        "4ormat": "#fb0a2a",
                        "500px": "#02adea",
                        "About.me (blue)": "#00405d",
                        "About.me (yellow)": "#ffcc33",
                        Addvocate: "#ff6138",
                        Adobe: "#ff0000",
                        Aim: "#fcd20b",
                        Amazon: "#e47911",
                        Android: "#a4c639",
                        "Angie's List": "#7fbb00",
                        AOL: "#0060a3",
                        Atlassian: "#003366",
                        Behance: "#053eff",
                        "Big Cartel": "#97b538",
                        bitly: "#ee6123",
                        Blogger: "#fc4f08",
                        Boeing: "#0039a6",
                        "Booking.com": "#003580",
                        Carbonmade: "#613854",
                        Cheddar: "#ff7243",
                        "Code School": "#3d4944",
                        Delicious: "#205cc0",
                        Dell: "#3287c1",
                        Designmoo: "#e54a4f",
                        Deviantart: "#4e6252",
                        "Designer News": "#2d72da",
                        Devour: "#fd0001",
                        DEWALT: "#febd17",
                        "Disqus (blue)": "#59a3fc",
                        "Disqus (orange)": "#db7132",
                        Dribbble: "#ea4c89",
                        Dropbox: "#3d9ae8",
                        Drupal: "#0c76ab",
                        Dunked: "#2a323a",
                        eBay: "#89c507",
                        Ember: "#f05e1b",
                        Engadget: "#00bdf6",
                        Envato: "#528036",
                        Etsy: "#eb6d20",
                        Evernote: "#5ba525",
                        "Fab.com": "#dd0017",
                        Facebook: "#3b5998",
                        Firefox: "#e66000",
                        "Flickr (blue)": "#0063dc",
                        "Flickr (pink)": "#ff0084",
                        Forrst: "#5b9a68",
                        Foursquare: "#25a0ca",
                        Garmin: "#007cc3",
                        GetGlue: "#2d75a2",
                        Gimmebar: "#f70078",
                        GitHub: "#171515",
                        "Google Blue": "#0140ca",
                        "Google Green": "#16a61e",
                        "Google Red": "#dd1812",
                        "Google Yellow": "#fcca03",
                        "Google+": "#dd4b39",
                        Grooveshark: "#f77f00",
                        Groupon: "#82b548",
                        "Hacker News": "#ff6600",
                        HelloWallet: "#0085ca",
                        "Heroku (light)": "#c7c5e6",
                        "Heroku (dark)": "#6567a5",
                        HootSuite: "#003366",
                        Houzz: "#73ba37",
                        HTML5: "#ec6231",
                        IKEA: "#ffcc33",
                        IMDb: "#f3ce13",
                        Instagram: "#3f729b",
                        Intel: "#0071c5",
                        Intuit: "#365ebf",
                        Kickstarter: "#76cc1e",
                        kippt: "#e03500",
                        Kodery: "#00af81",
                        LastFM: "#c3000d",
                        LinkedIn: "#0e76a8",
                        Livestream: "#cf0005",
                        Lumo: "#576396",
                        Mixpanel: "#a086d3",
                        Meetup: "#e51937",
                        Nokia: "#183693",
                        NVIDIA: "#76b900",
                        Opera: "#cc0f16",
                        Path: "#e41f11",
                        "PayPal (dark)": "#1e477a",
                        "PayPal (light)": "#3b7bbf",
                        Pinboard: "#0000e6",
                        Pinterest: "#c8232c",
                        PlayStation: "#665cbe",
                        Pocket: "#ee4056",
                        Prezi: "#318bff",
                        Pusha: "#0f71b4",
                        Quora: "#a82400",
                        "QUOTE.fm": "#66ceff",
                        Rdio: "#008fd5",
                        Readability: "#9c0000",
                        "Red Hat": "#cc0000",
                        Resource: "#7eb400",
                        Rockpack: "#0ba6ab",
                        Roon: "#62b0d9",
                        RSS: "#ee802f",
                        Salesforce: "#1798c1",
                        Samsung: "#0c4da2",
                        Shopify: "#96bf48",
                        Skype: "#00aff0",
                        Snagajob: "#f47a20",
                        Softonic: "#008ace",
                        SoundCloud: "#ff7700",
                        "Space Box": "#f86960",
                        Spotify: "#81b71a",
                        Sprint: "#fee100",
                        Squarespace: "#121212",
                        StackOverflow: "#ef8236",
                        Staples: "#cc0000",
                        "Status Chart": "#d7584f",
                        Stripe: "#008cdd",
                        StudyBlue: "#00afe1",
                        StumbleUpon: "#f74425",
                        "T-Mobile": "#ea0a8e",
                        Technorati: "#40a800",
                        "The Next Web": "#ef4423",
                        Treehouse: "#5cb868",
                        Trulia: "#5eab1f",
                        Tumblr: "#34526f",
                        "Twitch.tv": "#6441a5",
                        Twitter: "#00acee",
                        TYPO3: "#ff8700",
                        Ubuntu: "#dd4814",
                        Ustream: "#3388ff",
                        Verizon: "#ef1d1d",
                        Vimeo: "#86c9ef",
                        Vine: "#00a478",
                        Virb: "#06afd8",
                        "Virgin Media": "#cc0000",
                        Wooga: "#5b009c",
                        "WordPress (blue)": "#21759b",
                        "WordPress (orange)": "#d54e21",
                        "WordPress (grey)": "#464646",
                        Wunderlist: "#2b88d9",
                        XBOX: "#9bc848",
                        XING: "#126567",
                        "Yahoo!": "#720e9e",
                        Yandex: "#ffcc00",
                        Yelp: "#c41200",
                        YouTube: "#c4302b",
                        Zalongo: "#5498dc",
                        Zendesk: "#78a300",
                        Zerply: "#9dcc7a",
                        Zootool: "#5e8b1d"
                    },
                    _brandNames: function() {
                        var t = [];
                        for (var e in this._brandColors) t.push(e);
                        return t
                    },
                    dataImage: function(e, n) {
                        var r;
                        "undefined" != typeof document ? r = document.createElement("canvas") : r = new(t.require("canvas"));
                        var a = r && r.getContext && r.getContext("2d");
                        if (!r || !a) return "";
                        e || (e = this.pick(this._adSize)),
                        n = void 0 !== n ? n: e,
                        e = e.split("x");
                        var o = parseInt(e[0], 10),
                        i = parseInt(e[1], 10),
                        u = this._brandColors[this.pick(this._brandNames())];
                        return r.width = o,
                        r.height = i,
                        a.textAlign = "center",
                        a.textBaseline = "middle",
                        a.fillStyle = u,
                        a.fillRect(0, 0, o, i),
                        a.fillStyle = "#FFF",
                        a.font = "bold 14px sans-serif",
                        a.fillText(n, o / 2, i / 2, o),
                        r.toDataURL("image/png")
                    }
                }
            }).call(e, n(9)(t))
        },
        function(t, e) {
            t.exports = function(t) {
                return t.webpackPolyfill || (t.deprecate = function() {},
                t.paths = [], t.children = [], t.webpackPolyfill = 1),
                t
            }
        },
        function(t, e, n) {
            var r = n(11),
            a = n(12);
            t.exports = {
                color: function(t) {
                    return t || a[t] ? a[t].nicer: this.hex()
                },
                hex: function() {
                    var t = this._goldenRatioColor(),
                    e = r.hsv2rgb(t);
                    return r.rgb2hex(e[0], e[1], e[2])
                },
                rgb: function() {
                    var t = this._goldenRatioColor(),
                    e = r.hsv2rgb(t);
                    return "rgb(" + parseInt(e[0], 10) + ", " + parseInt(e[1], 10) + ", " + parseInt(e[2], 10) + ")"
                },
                rgba: function() {
                    var t = this._goldenRatioColor(),
                    e = r.hsv2rgb(t);
                    return "rgba(" + parseInt(e[0], 10) + ", " + parseInt(e[1], 10) + ", " + parseInt(e[2], 10) + ", " + Math.random().toFixed(2) + ")"
                },
                hsl: function() {
                    var t = this._goldenRatioColor(),
                    e = r.hsv2hsl(t);
                    return "hsl(" + parseInt(e[0], 10) + ", " + parseInt(e[1], 10) + ", " + parseInt(e[2], 10) + ")"
                },
                _goldenRatioColor: function(t, e) {
                    return this._goldenRatio = .618033988749895,
                    this._hue = this._hue || Math.random(),
                    this._hue += this._goldenRatio,
                    this._hue %= 1,
                    "number" != typeof t && (t = .5),
                    "number" != typeof e && (e = .95),
                    [360 * this._hue, 100 * t, 100 * e]
                }
            }
        },
        function(t, e) {
            t.exports = {
                rgb2hsl: function(t) {
                    var e, n, r = t[0] / 255,
                    a = t[1] / 255,
                    o = t[2] / 255,
                    i = Math.min(r, a, o),
                    u = Math.max(r, a, o),
                    l = u - i;
                    return u == i ? e = 0 : r == u ? e = (a - o) / l: a == u ? e = 2 + (o - r) / l: o == u && (e = 4 + (r - a) / l),
                    0 > (e = Math.min(60 * e, 360)) && (e += 360),
                    n = (i + u) / 2,
                    [e, 100 * (u == i ? 0 : .5 >= n ? l / (u + i) : l / (2 - u - i)), 100 * n]
                },
                rgb2hsv: function(t) {
                    var e, n, r = t[0],
                    a = t[1],
                    o = t[2],
                    i = Math.min(r, a, o),
                    u = Math.max(r, a, o),
                    l = u - i;
                    return n = 0 === u ? 0 : l / u * 1e3 / 10,
                    u == i ? e = 0 : r == u ? e = (a - o) / l: a == u ? e = 2 + (o - r) / l: o == u && (e = 4 + (r - a) / l),
                    0 > (e = Math.min(60 * e, 360)) && (e += 360),
                    [e, n, u / 255 * 1e3 / 10]
                },
                hsl2rgb: function(t) {
                    var e, n, r, a, o, i = t[0] / 360,
                    u = t[1] / 100,
                    l = t[2] / 100;
                    if (0 === u) return [o = 255 * l, o, o];
                    e = 2 * l - (n = .5 > l ? l * (1 + u) : l + u - l * u),
                    a = [0, 0, 0];
                    for (var s = 0; 3 > s; s++) 0 > (r = i + 1 / 3 * -(s - 1)) && r++,
                    r > 1 && r--,
                    o = 1 > 6 * r ? e + 6 * (n - e) * r: 1 > 2 * r ? n: 2 > 3 * r ? e + (n - e) * (2 / 3 - r) * 6 : e,
                    a[s] = 255 * o;
                    return a
                },
                hsl2hsv: function(t) {
                    var e = t[0],
                    n = t[1] / 100,
                    r = t[2] / 100;
                    return [e, 100 * (2 * (n *= 1 >= (r *= 2) ? r: 2 - r) / (r + n)), 100 * ((r + n) / 2)]
                },
                hsv2rgb: function(t) {
                    var e = t[0] / 60,
                    n = t[1] / 100,
                    r = t[2] / 100,
                    a = Math.floor(e) % 6,
                    o = e - Math.floor(e),
                    i = 255 * r * (1 - n),
                    u = 255 * r * (1 - n * o),
                    l = 255 * r * (1 - n * (1 - o));
                    switch (r *= 255, a) {
                    case 0:
                        return [r, l, i];
                    case 1:
                        return [u, r, i];
                    case 2:
                        return [i, r, l];
                    case 3:
                        return [i, u, r];
                    case 4:
                        return [l, i, r];
                    case 5:
                        return [r, i, u]
                    }
                },
                hsv2hsl: function(t) {
                    var e, n, r = t[0],
                    a = t[1] / 100,
                    o = t[2] / 100;
                    return e = a * o,
                    [r, 100 * (e /= 1 >= (n = (2 - a) * o) ? n: 2 - n), 100 * (n /= 2)]
                },
                rgb2hex: function(t, e, n) {
                    return "#" + ((256 + t << 8 | e) << 8 | n).toString(16).slice(1)
                },
                hex2rgb: function(t) {
                    return [(t = "0x" + t.slice(1).replace(t.length > 4 ? t: /./g, "$&$&") | 0) >> 16, t >> 8 & 255, 255 & t]
                }
            }
        },
        function(t, e) {
            t.exports = {
                navy: {
                    value: "#000080",
                    nicer: "#001F3F"
                },
                blue: {
                    value: "#0000ff",
                    nicer: "#0074D9"
                },
                aqua: {
                    value: "#00ffff",
                    nicer: "#7FDBFF"
                },
                teal: {
                    value: "#008080",
                    nicer: "#39CCCC"
                },
                olive: {
                    value: "#008000",
                    nicer: "#3D9970"
                },
                green: {
                    value: "#008000",
                    nicer: "#2ECC40"
                },
                lime: {
                    value: "#00ff00",
                    nicer: "#01FF70"
                },
                yellow: {
                    value: "#ffff00",
                    nicer: "#FFDC00"
                },
                orange: {
                    value: "#ffa500",
                    nicer: "#FF851B"
                },
                red: {
                    value: "#ff0000",
                    nicer: "#FF4136"
                },
                maroon: {
                    value: "#800000",
                    nicer: "#85144B"
                },
                fuchsia: {
                    value: "#ff00ff",
                    nicer: "#F012BE"
                },
                purple: {
                    value: "#800080",
                    nicer: "#B10DC9"
                },
                silver: {
                    value: "#c0c0c0",
                    nicer: "#DDDDDD"
                },
                gray: {
                    value: "#808080",
                    nicer: "#AAAAAA"
                },
                black: {
                    value: "#000000",
                    nicer: "#111111"
                },
                white: {
                    value: "#FFFFFF",
                    nicer: "#FFFFFF"
                }
            }
        },
        function(t, e, n) {
            function r(t, e, n, r) {
                return void 0 === n ? a.natural(t, e) : void 0 === r ? n: a.natural(parseInt(n, 10), parseInt(r, 10))
            }
            var a = n(6),
            o = n(14);
            t.exports = {
                paragraph: function(t, e) {
                    for (var n = r(3, 7, t, e), a = [], o = 0; n > o; o++) a.push(this.sentence());
                    return a.join(" ")
                },
                cparagraph: function(t, e) {
                    for (var n = r(3, 7, t, e), a = [], o = 0; n > o; o++) a.push(this.csentence());
                    return a.join("")
                },
                sentence: function(t, e) {
                    for (var n = r(12, 18, t, e), a = [], i = 0; n > i; i++) a.push(this.word());
                    return o.capitalize(a.join(" ")) + "."
                },
                csentence: function(t, e) {
                    for (var n = r(12, 18, t, e), a = [], o = 0; n > o; o++) a.push(this.cword());
                    return a.join("") + "。"
                },
                word: function(t, e) {
                    for (var n = r(3, 10, t, e), o = "", i = 0; n > i; i++) o += a.character("lower");
                    return o
                },
                cword: function(t, e, n) {
                    var r, a = "了的吗";
                    switch (arguments.length) {
                    case 0:
                        t = a,
                        r = 1;
                        break;
                    case 1:
                        "string" == typeof arguments[0] ? r = 1 : (r = t, t = a);
                        break;
                    case 2:
                        "string" == typeof arguments[0] ? r = e: (r = this.natural(t, e), t = a);
                        break;
                    case 3:
                        r = this.natural(e, n)
                    }
                    for (var o = "",
                    i = 0; r > i; i++) o += t.charAt(this.natural(0, t.length - 1));
                    return o
                },
                title: function(t, e) {
                    for (var n = r(3, 7, t, e), a = [], o = 0; n > o; o++) a.push(this.capitalize(this.word()));
                    return a.join(" ")
                },
                ctitle: function(t, e) {
                    for (var n = r(3, 7, t, e), a = [], o = 0; n > o; o++) a.push(this.cword());
                    return a.join("")
                }
            }
        },
        function(t, e, n) {
            var r = n(3);
            t.exports = {
                capitalize: function(t) {
                    return (t + "").charAt(0).toUpperCase() + (t + "").substr(1)
                },
                upper: function(t) {
                    return (t + "").toUpperCase()
                },
                lower: function(t) {
                    return (t + "").toLowerCase()
                },
                pick: function(t, e, n) {
                    return r.isArray(t) ? (void 0 === e && (e = 1), void 0 === n && (n = e)) : (t = [].slice.call(arguments), e = 1, n = 1),
                    1 === e && 1 === n ? t[this.natural(0, t.length - 1)] : this.shuffle(t, e, n)
                },
                shuffle: function(t, e, n) {
                    for (var r = (t = t || []).slice(0), a = [], o = 0, i = r.length, u = 0; i > u; u++) o = this.natural(0, r.length - 1),
                    a.push(r[o]),
                    r.splice(o, 1);
                    switch (arguments.length) {
                    case 0:
                    case 1:
                        return a;
                    case 2:
                        n = e;
                    case 3:
                        return e = parseInt(e, 10),
                        n = parseInt(n, 10),
                        a.slice(0, this.natural(e, n))
                    }
                },
                order: function t(e) {
                    t.cache = t.cache || {},
                    arguments.length > 1 && (e = [].slice.call(arguments, 0));
                    var n = t.options.context.templatePath.join("."),
                    r = t.cache[n] = t.cache[n] || {
                        index: 0,
                        array: e
                    };
                    return r.array[r.index++%r.array.length]
                }
            }
        },
        function(t, e) {
            t.exports = {
                first: function() {
                    var t = [].concat([]);
                    return this.pick(t)
                },
                last: function() {
                    return this.pick([])
                },
                name: function(t) {
                    return this.first() + " " + (t ? this.first() + " ": "") + this.last()
                },
                cfirst: function() {
                    var t = "".split(" ");
                    return this.pick(t)
                },
                clast: function() {
                    var t = "".split(" ");
                    return this.pick(t)
                },
                cname: function() {
                    return this.cfirst() + this.clast()
                }
            }
        },
        function(t, e) {
            t.exports = {
                url: function(t, e) {
                    return (t || this.protocol()) + "://" + (e || this.domain()) + "/" + this.word()
                },
                protocol: function() {
                    return this.pick("".split(" "))
                },
                domain: function(t) {
                    return this.word() + "." + (t || this.tld())
                },
                tld: function() {
                    return this.pick("".split(" "))
                },
                email: function(t) {
                    return this.character("lower") + "." + this.word() + "@" + (t || this.word() + "." + this.tld())
                },
                ip: function() {
                    return this.natural(0, 255) + "." + this.natural(0, 255) + "." + this.natural(0, 255) + "." + this.natural(0, 255)
                }
            }
        },
        function(t, e, n) {
            var r = n(18),
            a = [];
            t.exports = {
                region: function() {
                    return this.pick(a)
                },
                province: function() {
                    return this.pick(r).name
                },
                city: function(t) {
                    var e = this.pick(r),
                    n = this.pick(e.children);
                    return t ? [e.name, n.name].join(" ") : n.name
                },
                county: function(t) {
                    var e = this.pick(r),
                    n = this.pick(e.children),
                    a = this.pick(n.children) || {
                        name: "-"
                    };
                    return t ? [e.name, n.name, a.name].join(" ") : a.name
                },
                zip: function(t) {
                    for (var e = "",
                    n = 0; (t || 6) > n; n++) e += this.natural(0, 9);
                    return e
                }
            }
        },
        function(t, e) {
            var n = {
            },
            r = function() {
                var t = [];
                for (var e in n) {
                    var r = "0000" === e.slice(2, 6) ? void 0 : "00" == e.slice(4, 6) ? e.slice(0, 2) + "0000": e.slice(0, 4) + "00";
                    t.push({
                        id: e,
                        pid: r,
                        name: n[e]
                    })
                }
                return function(t) {
                    for (var e, n = {},
                    r = 0; r < t.length; r++)(e = t[r]) && e.id && (n[e.id] = e);
                    for (var a = [], o = 0; o < t.length; o++) if (e = t[o]) if (void 0 != e.pid || void 0 != e.parentId) {
                        var i = n[e.pid] || n[e.parentId];
                        i && (i.children || (i.children = []), i.children.push(e))
                    } else a.push(e);
                    return a
                } (t)
            } ();
            t.exports = r
        },
        function(t, e, n) {
            var r, a = n(18);
            t.exports = {
                d4: function() {
                    return this.natural(1, 4)
                },
                d6: function() {
                    return this.natural(1, 6)
                },
                d8: function() {
                    return this.natural(1, 8)
                },
                d12: function() {
                    return this.natural(1, 12)
                },
                d20: function() {
                    return this.natural(1, 20)
                },
                d100: function() {
                    return this.natural(1, 100)
                },
                guid: function() {
                    var t = "abcdefABCDEF1234567890";
                    return this.string(t, 8) + "-" + this.string(t, 4) + "-" + this.string(t, 4) + "-" + this.string(t, 4) + "-" + this.string(t, 12)
                },
                uuid: function() {
                    return this.guid()
                },
                id: function() {
                    var t, e = 0,
                    n = ["7", "9", "10", "5", "8", "4", "2", "1", "6", "3", "7", "9", "10", "5", "8", "4", "2"];
                    t = this.pick(a).id + this.date("yyyyMMdd") + this.string("number", 3);
                    for (var r = 0; r < t.length; r++) e += t[r] * n[r];
                    return t + ["1", "0", "X", "9", "8", "7", "6", "5", "4", "3", "2"][e % 11]
                },
                increment: (r = 0,
                function(t) {
                    return r += +t || 1
                }),
                inc: function(t) {
                    return this.increment(t)
                }
            }
        },
        function(t, e, n) {
            var r = n(21),
            a = n(22);
            t.exports = {
                Parser: r,
                Handler: a
            }
        },
        function(t, e) {
            function n(t) {
                this.type = t,
                this.offset = n.offset(),
                this.text = n.text()
            }
            function r(t, e) {
                n.call(this, t),
                this.body = e
            }
            function a(t, e) {
                n.call(this, "quantifier"),
                this.min = t,
                this.max = e,
                this.greedy = !0
            }
            var o = function() {
                function t(t, e, n, r, a) {
                    this.expected = t,
                    this.found = e,
                    this.offset = n,
                    this.line = r,
                    this.column = a,
                    this.name = "SyntaxError",
                    this.message = function(t, e) {
                        var n;
                        switch (t.length) {
                        case 0:
                            n = "end of input";
                            break;
                        case 1:
                            n = t[0];
                            break;
                        default:
                            n = t.slice(0, -1).join(", ") + " or " + t[t.length - 1]
                        }
                        return "Expected " + n + " but " + (e ? '"' +
                        function(t) {
                            function e(t) {
                                return t.charCodeAt(0).toString(16).toUpperCase()
                            }
                            return t.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\x08/g, "\\b").replace(/\t/g, "\\t").replace(/\n/g, "\\n").replace(/\f/g, "\\f").replace(/\r/g, "\\r").replace(/[\x00-\x07\x0B\x0E\x0F]/g,
                            function(t) {
                                return "\\x0" + e(t)
                            }).replace(/[\x10-\x1F\x80-\xFF]/g,
                            function(t) {
                                return "\\x" + e(t)
                            }).replace(/[\u0180-\u0FFF]/g,
                            function(t) {
                                return "\\u0" + e(t)
                            }).replace(/[\u1080-\uFFFF]/g,
                            function(t) {
                                return "\\u" + e(t)
                            })
                        } (e) + '"': "end of input") + " found."
                    } (t, e)
                }
                return function(t, e) {
                    function n() {
                        this.constructor = t
                    }
                    n.prototype = e.prototype,
                    t.prototype = new n
                } (t, Error),
                {
                    SyntaxError: t,
                    parse: function(e) {
                        function o(t) {
                            return dn !== t && (dn > t && (dn = 0, mn = {
                                line: 1,
                                column: 1,
                                seenCR: !1
                            }),
                            function(t, n, r) {
                                var a, o;
                                for (a = n; r > a; a++)"\n" === (o = e.charAt(a)) ? (t.seenCR || t.line++, t.column = 1, t.seenCR = !1) : "\r" === o || "\u2028" === o || "\u2029" === o ? (t.line++, t.column = 1, t.seenCR = !0) : (t.column++, t.seenCR = !1)
                            } (mn, dn, t), dn = t),
                            mn
                        }
                        function l(t) {
                            gn > pn || (pn > gn && (gn = pn, vn = []), vn.push(t))
                        }
                        function s() {
                            var t, n, r, a, o;
                            return t = pn,
                            null !== (n = function() {
                                var t, n, r, a, o, i, u, s, f;
                                if (t = pn, null === (s = pn, 94 === e.charCodeAt(pn) ? (f = B, pn++) : (f = null, 0 === xn && l(G)), null !== f && (fn = s, f = X()), null === f ? (pn = s, s = f) : s = f, n = s) && (n = I), null !== n) if (r = pn, xn++, a = p(), xn--, null === a ? r = I: (pn = r, r = O), null !== r) {
                                    for (a = [], null === (o = h()) && (o = c()); null !== o;) a.push(o),
                                    null === (o = h()) && (o = c());
                                    null !== a ? (i = pn, 36 === e.charCodeAt(pn) ? (u = K, pn++) : (u = null, 0 === xn && l(W)), null !== u && (fn = i, u = Y()), null === u ? (pn = i, i = u) : i = u, null === (o = i) && (o = I), null !== o ? (fn = t, null === (n = U(n, a, o)) ? (pn = t, t = n) : t = n) : (pn = t, t = O)) : (pn = t, t = O)
                                } else pn = t,
                                t = O;
                                else pn = t,
                                t = O;
                                return t
                            } ()) ? (r = pn, 124 === e.charCodeAt(pn) ? (a = j, pn++) : (a = null, 0 === xn && l(N)), null !== a && null !== (o = s()) ? r = a = [a, o] : (pn = r, r = O), null === r && (r = I), null !== r ? (fn = t, null === (n = z(n, r)) ? (pn = t, t = n) : t = n) : (pn = t, t = O)) : (pn = t, t = O),
                            t
                        }
                        function c() {
                            var t, n, r, a, o, i, u, c, h, p, f, q, D, F, L, j, N, z, U, X, K, W, Y, $, J, V, Z, Q, tt;
                            return L = pn,
                            40 === e.charCodeAt(pn) ? (j = wt, pn++) : (j = null, 0 === xn && l(Ct)),
                            null !== j ? (null === (Z = pn, e.substr(pn, 2) === St ? (Q = St, pn += 2) : (Q = null, 0 === xn && l(Tt)), null !== Q && null !== (tt = s()) ? (fn = Z, null === (Q = Ht(tt)) ? (pn = Z, Z = Q) : Z = Q) : (pn = Z, Z = O), N = Z) && null === ($ = pn, e.substr(pn, 2) === qt ? (J = qt, pn += 2) : (J = null, 0 === xn && l(Dt)), null !== J && null !== (V = s()) ? (fn = $, null === (J = Ft(V)) ? (pn = $, $ = J) : $ = J) : (pn = $, $ = O), N = $) && null === (K = pn, e.substr(pn, 2) === _t ? (W = _t, pn += 2) : (W = null, 0 === xn && l(Mt)), null !== W && null !== (Y = s()) ? (fn = K, null === (W = Pt(Y)) ? (pn = K, K = W) : K = W) : (pn = K, K = O), N = K) && (U = pn, null !== (X = s()) && (fn = U, X = At(X)), null === X ? (pn = U, U = X) : U = X, N = U), null !== N ? (41 === e.charCodeAt(pn) ? (z = kt, pn++) : (z = null, 0 === xn && l(Et)), null !== z ? (fn = L, null === (j = Rt(N)) ? (pn = L, L = j) : L = j) : (pn = L, L = O)) : (pn = L, L = O)) : (pn = L, L = O),
                            null === (t = L) && null === (t = function() {
                                var t, n, r, a, o;
                                if (xn++, t = pn, 91 === e.charCodeAt(pn) ? (n = Ot, pn++) : (n = null, 0 === xn && l(It)), null !== n) if (94 === e.charCodeAt(pn) ? (r = B, pn++) : (r = null, 0 === xn && l(G)), null === r && (r = I), null !== r) {
                                    for (a = [], null === (o = d()) && (o = m()); null !== o;) a.push(o),
                                    null === (o = d()) && (o = m());
                                    null !== a ? (93 === e.charCodeAt(pn) ? (o = jt, pn++) : (o = null, 0 === xn && l(Nt)), null !== o ? (fn = t, null === (n = zt(r, a)) ? (pn = t, t = n) : t = n) : (pn = t, t = O)) : (pn = t, t = O)
                                } else pn = t,
                                t = O;
                                else pn = t,
                                t = O;
                                return xn--,
                                null === t && (n = null, 0 === xn && l(Lt)),
                                t
                            } ()) && (null === (D = pn, 46 === e.charCodeAt(pn) ? (F = Jt, pn++) : (F = null, 0 === xn && l(Vt)), null !== F && (fn = D, F = Zt()), null === F ? (pn = D, D = F) : D = F, n = D) && null === (null === (f = pn, e.substr(pn, 2) === ne ? (q = ne, pn += 2) : (q = null, 0 === xn && l(re)), null !== q && (fn = f, q = oe()), null === q ? (pn = f, f = q) : f = q, o = f) && null === (h = pn, e.substr(pn, 2) === ie ? (p = ie, pn += 2) : (p = null, 0 === xn && l(ue)), null !== p && (fn = h, p = le()), null === p ? (pn = h, h = p) : h = p, o = h) && null === (o = _()) && null === (o = g()) && null === (o = v()) && null === (o = x()) && null === (o = y()) && null === (o = b()) && null === (o = w()) && null === (o = C()) && null === (o = k()) && null === (o = E()) && null === (o = R()) && null === (o = A()) && null === (i = pn, 92 === e.charCodeAt(pn) ? (u = Ke, pn++) : (u = null, 0 === xn && l(We)), null !== u ? (Ye.test(e.charAt(pn)) ? (c = e.charAt(pn), pn++) : (c = null, 0 === xn && l($e)), null !== c ? (fn = i, null === (u = Je(c)) ? (pn = i, i = u) : i = u) : (pn = i, i = O)) : (pn = i, i = O), o = i) && null === (o = M()) && null === (o = P()) && null === (o = S()) && null === (o = T()) && (o = H()), n = o) && (xn++, r = pn, te.test(e.charAt(pn)) ? (a = e.charAt(pn), pn++) : (a = null, 0 === xn && l(ee)), null !== a && (fn = r, a = $t(a)), null === a ? (pn = r, r = a) : r = a, xn--, null === r && (a = null, 0 === xn && l(Qt)), n = r), t = n),
                            t
                        }
                        function h() {
                            var t, e, n;
                            return t = pn,
                            null !== (e = c()) && null !== (n = p()) ? (fn = t, null === (e = $(e, n)) ? (pn = t, t = e) : t = e) : (pn = t, t = O),
                            t
                        }
                        function p() {
                            var t, n, r, a, o, i, u, s, c, h, p, d, m, g, v, x, y, b, w, C, k, E, R, A, _;
                            return xn++,
                            t = pn,
                            null === (C = pn, 123 === e.charCodeAt(pn) ? (k = Z, pn++) : (k = null, 0 === xn && l(Q)), null !== k && null !== (E = f()) ? (44 === e.charCodeAt(pn) ? (R = tt, pn++) : (R = null, 0 === xn && l(et)), null !== R && null !== (A = f()) ? (125 === e.charCodeAt(pn) ? (_ = nt, pn++) : (_ = null, 0 === xn && l(rt)), null !== _ ? (fn = C, null === (k = at(E, A)) ? (pn = C, C = k) : C = k) : (pn = C, C = O)) : (pn = C, C = O)) : (pn = C, C = O), o = C) && null === (x = pn, 123 === e.charCodeAt(pn) ? (y = Z, pn++) : (y = null, 0 === xn && l(Q)), null !== y && null !== (b = f()) ? (e.substr(pn, 2) === ot ? (w = ot, pn += 2) : (w = null, 0 === xn && l(it)), null !== w ? (fn = x, null === (y = ut(b)) ? (pn = x, x = y) : x = y) : (pn = x, x = O)) : (pn = x, x = O), o = x) && null === (d = pn, 123 === e.charCodeAt(pn) ? (m = Z, pn++) : (m = null, 0 === xn && l(Q)), null !== m && null !== (g = f()) ? (125 === e.charCodeAt(pn) ? (v = nt, pn++) : (v = null, 0 === xn && l(rt)), null !== v ? (fn = d, null === (m = lt(g)) ? (pn = d, d = m) : d = m) : (pn = d, d = O)) : (pn = d, d = O), o = d) && null === (h = pn, 43 === e.charCodeAt(pn) ? (p = st, pn++) : (p = null, 0 === xn && l(ct)), null !== p && (fn = h, p = ht()), null === p ? (pn = h, h = p) : h = p, o = h) && null === (s = pn, 42 === e.charCodeAt(pn) ? (c = pt, pn++) : (c = null, 0 === xn && l(ft)), null !== c && (fn = s, c = dt()), null === c ? (pn = s, s = c) : s = c, o = s) && (i = pn, 63 === e.charCodeAt(pn) ? (u = mt, pn++) : (u = null, 0 === xn && l(gt)), null !== u && (fn = i, u = vt()), null === u ? (pn = i, i = u) : i = u, o = i),
                            null !== (n = o) ? (63 === e.charCodeAt(pn) ? (a = mt, pn++) : (a = null, 0 === xn && l(gt)), null === (r = a) && (r = I), null !== r ? (fn = t, null === (n = V(n, r)) ? (pn = t, t = n) : t = n) : (pn = t, t = O)) : (pn = t, t = O),
                            xn--,
                            null === t && (n = null, 0 === xn && l(J)),
                            t
                        }
                        function f() {
                            var t, n, r;
                            if (t = pn, n = [], xt.test(e.charAt(pn)) ? (r = e.charAt(pn), pn++) : (r = null, 0 === xn && l(yt)), null !== r) for (; null !== r;) n.push(r),
                            xt.test(e.charAt(pn)) ? (r = e.charAt(pn), pn++) : (r = null, 0 === xn && l(yt));
                            else n = O;
                            return null !== n && (fn = t, n = bt(n)),
                            null === n ? (pn = t, t = n) : t = n,
                            t
                        }
                        function d() {
                            var t, n, r, a;
                            return xn++,
                            t = pn,
                            null !== (n = m()) ? (45 === e.charCodeAt(pn) ? (r = Bt, pn++) : (r = null, 0 === xn && l(Gt)), null !== r && null !== (a = m()) ? (fn = t, null === (n = Xt(n, a)) ? (pn = t, t = n) : t = n) : (pn = t, t = O)) : (pn = t, t = O),
                            xn--,
                            null === t && (n = null, 0 === xn && l(Ut)),
                            t
                        }
                        function m() {
                            var t, n, r, a, o, i;
                            return xn++,
                            null === (o = pn, e.substr(pn, 2) === ne ? (i = ne, pn += 2) : (i = null, 0 === xn && l(re)), null !== i && (fn = o, i = ae()), null === i ? (pn = o, o = i) : o = i, a = o) && null === (a = _()) && null === (a = g()) && null === (a = v()) && null === (a = x()) && null === (a = y()) && null === (a = b()) && null === (a = w()) && null === (a = C()) && null === (a = k()) && null === (a = E()) && null === (a = R()) && null === (a = A()) && null === (a = M()) && null === (a = P()) && null === (a = S()) && null === (a = T()) && (a = H()),
                            null === (t = a) && (n = pn, Wt.test(e.charAt(pn)) ? (r = e.charAt(pn), pn++) : (r = null, 0 === xn && l(Yt)), null !== r && (fn = n, r = $t(r)), null === r ? (pn = n, n = r) : n = r, t = n),
                            xn--,
                            null === t && 0 === xn && l(Kt),
                            t
                        }
                        function g() {
                            var t, n;
                            return t = pn,
                            e.substr(pn, 2) === se ? (n = se, pn += 2) : (n = null, 0 === xn && l(ce)),
                            null !== n && (fn = t, n = he()),
                            null === n ? (pn = t, t = n) : t = n,
                            t
                        }
                        function v() {
                            var t, n;
                            return t = pn,
                            e.substr(pn, 2) === pe ? (n = pe, pn += 2) : (n = null, 0 === xn && l(fe)),
                            null !== n && (fn = t, n = de()),
                            null === n ? (pn = t, t = n) : t = n,
                            t
                        }
                        function x() {
                            var t, n;
                            return t = pn,
                            e.substr(pn, 2) === me ? (n = me, pn += 2) : (n = null, 0 === xn && l(ge)),
                            null !== n && (fn = t, n = ve()),
                            null === n ? (pn = t, t = n) : t = n,
                            t
                        }
                        function y() {
                            var t, n;
                            return t = pn,
                            e.substr(pn, 2) === xe ? (n = xe, pn += 2) : (n = null, 0 === xn && l(ye)),
                            null !== n && (fn = t, n = be()),
                            null === n ? (pn = t, t = n) : t = n,
                            t
                        }
                        function b() {
                            var t, n;
                            return t = pn,
                            e.substr(pn, 2) === we ? (n = we, pn += 2) : (n = null, 0 === xn && l(Ce)),
                            null !== n && (fn = t, n = ke()),
                            null === n ? (pn = t, t = n) : t = n,
                            t
                        }
                        function w() {
                            var t, n;
                            return t = pn,
                            e.substr(pn, 2) === Ee ? (n = Ee, pn += 2) : (n = null, 0 === xn && l(Re)),
                            null !== n && (fn = t, n = Ae()),
                            null === n ? (pn = t, t = n) : t = n,
                            t
                        }
                        function C() {
                            var t, n;
                            return t = pn,
                            e.substr(pn, 2) === _e ? (n = _e, pn += 2) : (n = null, 0 === xn && l(Me)),
                            null !== n && (fn = t, n = Pe()),
                            null === n ? (pn = t, t = n) : t = n,
                            t
                        }
                        function k() {
                            var t, n;
                            return t = pn,
                            e.substr(pn, 2) === Se ? (n = Se, pn += 2) : (n = null, 0 === xn && l(Te)),
                            null !== n && (fn = t, n = He()),
                            null === n ? (pn = t, t = n) : t = n,
                            t
                        }
                        function E() {
                            var t, n;
                            return t = pn,
                            e.substr(pn, 2) === qe ? (n = qe, pn += 2) : (n = null, 0 === xn && l(De)),
                            null !== n && (fn = t, n = Fe()),
                            null === n ? (pn = t, t = n) : t = n,
                            t
                        }
                        function R() {
                            var t, n;
                            return t = pn,
                            e.substr(pn, 2) === Le ? (n = Le, pn += 2) : (n = null, 0 === xn && l(Oe)),
                            null !== n && (fn = t, n = Ie()),
                            null === n ? (pn = t, t = n) : t = n,
                            t
                        }
                        function A() {
                            var t, n;
                            return t = pn,
                            e.substr(pn, 2) === je ? (n = je, pn += 2) : (n = null, 0 === xn && l(Ne)),
                            null !== n && (fn = t, n = ze()),
                            null === n ? (pn = t, t = n) : t = n,
                            t
                        }
                        function _() {
                            var t, n, r;
                            return t = pn,
                            e.substr(pn, 2) === Ue ? (n = Ue, pn += 2) : (n = null, 0 === xn && l(Be)),
                            null !== n ? (e.length > pn ? (r = e.charAt(pn), pn++) : (r = null, 0 === xn && l(Ge)), null !== r ? (fn = t, null === (n = Xe(r)) ? (pn = t, t = n) : t = n) : (pn = t, t = O)) : (pn = t, t = O),
                            t
                        }
                        function M() {
                            var t, n, r, a;
                            if (t = pn, e.substr(pn, 2) === Ve ? (n = Ve, pn += 2) : (n = null, 0 === xn && l(Ze)), null !== n) {
                                if (r = [], Qe.test(e.charAt(pn)) ? (a = e.charAt(pn), pn++) : (a = null, 0 === xn && l(tn)), null !== a) for (; null !== a;) r.push(a),
                                Qe.test(e.charAt(pn)) ? (a = e.charAt(pn), pn++) : (a = null, 0 === xn && l(tn));
                                else r = O;
                                null !== r ? (fn = t, null === (n = en(r)) ? (pn = t, t = n) : t = n) : (pn = t, t = O)
                            } else pn = t,
                            t = O;
                            return t
                        }
                        function P() {
                            var t, n, r, a;
                            if (t = pn, e.substr(pn, 2) === nn ? (n = nn, pn += 2) : (n = null, 0 === xn && l(rn)), null !== n) {
                                if (r = [], an.test(e.charAt(pn)) ? (a = e.charAt(pn), pn++) : (a = null, 0 === xn && l(on)), null !== a) for (; null !== a;) r.push(a),
                                an.test(e.charAt(pn)) ? (a = e.charAt(pn), pn++) : (a = null, 0 === xn && l(on));
                                else r = O;
                                null !== r ? (fn = t, null === (n = un(r)) ? (pn = t, t = n) : t = n) : (pn = t, t = O)
                            } else pn = t,
                            t = O;
                            return t
                        }
                        function S() {
                            var t, n, r, a;
                            if (t = pn, e.substr(pn, 2) === ln ? (n = ln, pn += 2) : (n = null, 0 === xn && l(sn)), null !== n) {
                                if (r = [], an.test(e.charAt(pn)) ? (a = e.charAt(pn), pn++) : (a = null, 0 === xn && l(on)), null !== a) for (; null !== a;) r.push(a),
                                an.test(e.charAt(pn)) ? (a = e.charAt(pn), pn++) : (a = null, 0 === xn && l(on));
                                else r = O;
                                null !== r ? (fn = t, null === (n = cn(r)) ? (pn = t, t = n) : t = n) : (pn = t, t = O)
                            } else pn = t,
                            t = O;
                            return t
                        }
                        function T() {
                            var t, n;
                            return t = pn,
                            e.substr(pn, 2) === Ve ? (n = Ve, pn += 2) : (n = null, 0 === xn && l(Ze)),
                            null !== n && (fn = t, n = hn()),
                            null === n ? (pn = t, t = n) : t = n,
                            t
                        }
                        function H() {
                            var t, n, r;
                            return t = pn,
                            92 === e.charCodeAt(pn) ? (n = Ke, pn++) : (n = null, 0 === xn && l(We)),
                            null !== n ? (e.length > pn ? (r = e.charAt(pn), pn++) : (r = null, 0 === xn && l(Ge)), null !== r ? (fn = t, null === (n = $t(r)) ? (pn = t, t = n) : t = n) : (pn = t, t = O)) : (pn = t, t = O),
                            t
                        }
                        var q, D = arguments.length > 1 ? arguments[1] : {},
                        F = {
                            regexp: s
                        },
                        L = s,
                        O = null,
                        I = "",
                        j = "|",
                        N = '"|"',
                        z = function(t, e) {
                            return e ? new
                            function(t, e) {
                                n.call(this, "alternate"),
                                this.left = t,
                                this.right = e
                            } (t, e[1]) : t
                        },
                        U = function(t, e, r) {
                            return new
                            function(t) {
                                n.call(this, "match"),
                                this.body = t.filter(Boolean)
                            } ([t].concat(e).concat([r]))
                        },
                        B = "^",
                        G = '"^"',
                        X = function() {
                            return new n("start")
                        },
                        K = "$",
                        W = '"$"',
                        Y = function() {
                            return new n("end")
                        },
                        $ = function(t, e) {
                            return new
                            function(t, e) {
                                n.call(this, "quantified"),
                                this.body = t,
                                this.quantifier = e
                            } (t, e)
                        },
                        J = "Quantifier",
                        V = function(t, e) {
                            return e && (t.greedy = !1),
                            t
                        },
                        Z = "{",
                        Q = '"{"',
                        tt = ",",
                        et = '","',
                        nt = "}",
                        rt = '"}"',
                        at = function(t, e) {
                            return new a(t, e)
                        },
                        ot = ",}",
                        it = '",}"',
                        ut = function(t) {
                            return new a(t, 1 / 0)
                        },
                        lt = function(t) {
                            return new a(t, t)
                        },
                        st = "+",
                        ct = '"+"',
                        ht = function() {
                            return new a(1, 1 / 0)
                        },
                        pt = "*",
                        ft = '"*"',
                        dt = function() {
                            return new a(0, 1 / 0)
                        },
                        mt = "?",
                        gt = '"?"',
                        vt = function() {
                            return new a(0, 1)
                        },
                        xt = /^[0-9]/,
                        yt = "[0-9]",
                        bt = function(t) {
                            return + t.join("")
                        },
                        wt = "(",
                        Ct = '"("',
                        kt = ")",
                        Et = '")"',
                        Rt = function(t) {
                            return t
                        },
                        At = function(t) {
                            return new
                            function(t) {
                                r.call(this, "capture-group"),
                                this.index = u[this.offset] || (u[this.offset] = i++),
                                this.body = t
                            } (t)
                        },
                        _t = "?:",
                        Mt = '"?:"',
                        Pt = function(t) {
                            return new r("non-capture-group", t)
                        },
                        St = "?=",
                        Tt = '"?="',
                        Ht = function(t) {
                            return new r("positive-lookahead", t)
                        },
                        qt = "?!",
                        Dt = '"?!"',
                        Ft = function(t) {
                            return new r("negative-lookahead", t)
                        },
                        Lt = "CharacterSet",
                        Ot = "[",
                        It = '"["',
                        jt = "]",
                        Nt = '"]"',
                        zt = function(t, e) {
                            return new
                            function(t, e) {
                                n.call(this, "charset"),
                                this.invert = t,
                                this.body = e
                            } ( !! t, e)
                        },
                        Ut = "CharacterRange",
                        Bt = "-",
                        Gt = '"-"',
                        Xt = function(t, e) {
                            return new
                            function(t, e) {
                                n.call(this, "range"),
                                this.start = t,
                                this.end = e
                            } (t, e)
                        },
                        Kt = "Character",
                        Wt = /^[^\\\]]/,
                        Yt = "[^\\\\\\]]",
                        $t = function(t) {
                            return new
                            function(t) {
                                n.call(this, "literal"),
                                this.body = t,
                                this.escaped = this.body != this.text
                            } (t)
                        },
                        Jt = ".",
                        Vt = '"."',
                        Zt = function() {
                            return new n("any-character")
                        },
                        Qt = "Literal",
                        te = /^[^|\\\/.[()?+*$\^]/,
                        ee = "[^|\\\\\\/.[()?+*$\\^]",
                        ne = "\\b",
                        re = '"\\\\b"',
                        ae = function() {
                            return new n("backspace")
                        },
                        oe = function() {
                            return new n("word-boundary")
                        },
                        ie = "\\B",
                        ue = '"\\\\B"',
                        le = function() {
                            return new n("non-word-boundary")
                        },
                        se = "\\d",
                        ce = '"\\\\d"',
                        he = function() {
                            return new n("digit")
                        },
                        pe = "\\D",
                        fe = '"\\\\D"',
                        de = function() {
                            return new n("non-digit")
                        },
                        me = "\\f",
                        ge = '"\\\\f"',
                        ve = function() {
                            return new n("form-feed")
                        },
                        xe = "\\n",
                        ye = '"\\\\n"',
                        be = function() {
                            return new n("line-feed")
                        },
                        we = "\\r",
                        Ce = '"\\\\r"',
                        ke = function() {
                            return new n("carriage-return")
                        },
                        Ee = "\\s",
                        Re = '"\\\\s"',
                        Ae = function() {
                            return new n("white-space")
                        },
                        _e = "\\S",
                        Me = '"\\\\S"',
                        Pe = function() {
                            return new n("non-white-space")
                        },
                        Se = "\\t",
                        Te = '"\\\\t"',
                        He = function() {
                            return new n("tab")
                        },
                        qe = "\\v",
                        De = '"\\\\v"',
                        Fe = function() {
                            return new n("vertical-tab")
                        },
                        Le = "\\w",
                        Oe = '"\\\\w"',
                        Ie = function() {
                            return new n("word")
                        },
                        je = "\\W",
                        Ne = '"\\\\W"',
                        ze = function() {
                            return new n("non-word")
                        },
                        Ue = "\\c",
                        Be = '"\\\\c"',
                        Ge = "any character",
                        Xe = function(t) {
                            return new
                            function(t) {
                                n.call(this, "control-character"),
                                this.code = t.toUpperCase()
                            } (t)
                        },
                        Ke = "\\",
                        We = '"\\\\"',
                        Ye = /^[1-9]/,
                        $e = "[1-9]",
                        Je = function(t) {
                            return new
                            function(t) {
                                n.call(this, "back-reference"),
                                this.code = t.toUpperCase()
                            } (t)
                        },
                        Ve = "\\0",
                        Ze = '"\\\\0"',
                        Qe = /^[0-7]/,
                        tn = "[0-7]",
                        en = function(t) {
                            return new
                            function(t) {
                                n.call(this, "octal"),
                                this.code = t.toUpperCase()
                            } (t.join(""))
                        },
                        nn = "\\x",
                        rn = '"\\\\x"',
                        an = /^[0-9a-fA-F]/,
                        on = "[0-9a-fA-F]",
                        un = function(t) {
                            return new
                            function(t) {
                                n.call(this, "hex"),
                                this.code = t.toUpperCase()
                            } (t.join(""))
                        },
                        ln = "\\u",
                        sn = '"\\\\u"',
                        cn = function(t) {
                            return new
                            function(t) {
                                n.call(this, "unicode"),
                                this.code = t.toUpperCase()
                            } (t.join(""))
                        },
                        hn = function() {
                            return new n("null-character")
                        },
                        pn = 0,
                        fn = 0,
                        dn = 0,
                        mn = {
                            line: 1,
                            column: 1,
                            seenCR: !1
                        },
                        gn = 0,
                        vn = [],
                        xn = 0;
                        if ("startRule" in D) {
                            if (! (D.startRule in F)) throw new Error("Can't start parsing from rule \"" + D.startRule + '".');
                            L = F[D.startRule]
                        }
                        if (n.offset = function() {
                            return fn
                        },
                        n.text = function() {
                            return e.substring(fn, pn)
                        },
                        null !== (q = L()) && pn === e.length) return q;
                        throw function(t) {
                            var e = 0;
                            for (t.sort(); e < t.length;) t[e - 1] === t[e] ? t.splice(e, 1) : e++
                        } (vn),
                        fn = Math.max(pn, gn),
                        new t(vn, fn < e.length ? e.charAt(fn) : null, fn, o(fn).line, o(fn).column)
                    }
                }
            } (),
            i = 1,
            u = {};
            t.exports = o
        },
        function(t, e, n) {
            function r(t, e) {
                for (var n = "",
                r = t; e >= r; r++) n += String.fromCharCode(r);
                return n
            }
            var a = n(3),
            o = n(5),
            i = {
                extend: a.extend
            },
            u = r(97, 122),
            l = r(65, 90),
            s = r(48, 57),
            c = r(32, 47) + r(58, 64) + r(91, 96) + r(123, 126),
            h = r(32, 126),
            p = " \f\n\r\t\v \u2028\u2029",
            f = {
                "\\w": u + l + s + "_",
                "\\W": c.replace("_", ""),
                "\\s": p,
                "\\S": function() {
                    for (var t = h,
                    e = 0; e < p.length; e++) t = t.replace(p[e], "");
                    return t
                } (),
                "\\d": s,
                "\\D": u + l + c
            };
            i.gen = function(t, e, n) {
                return n = n || {
                    guid: 1
                },
                i[t.type] ? i[t.type](t, e, n) : i.token(t, e, n)
            },
            i.extend({
                token: function(t, e, n) {
                    switch (t.type) {
                    case "start":
                    case "end":
                        return "";
                    case "any-character":
                        return o.character();
                    case "backspace":
                    case "word-boundary":
                        return "";
                    case "non-word-boundary":
                        break;
                    case "digit":
                        return o.pick(s.split(""));
                    case "non-digit":
                        return o.pick((u + l + c).split(""));
                    case "form-feed":
                        break;
                    case "line-feed":
                        return t.body || t.text;
                    case "carriage-return":
                        break;
                    case "white-space":
                        return o.pick(p.split(""));
                    case "non-white-space":
                        return o.pick((u + l + s).split(""));
                    case "tab":
                    case "vertical-tab":
                        break;
                    case "word":
                        return o.pick((u + l + s).split(""));
                    case "non-word":
                        return o.pick(c.replace("_", "").split(""))
                    }
                    return t.body || t.text
                },
                alternate: function(t, e, n) {
                    return this.gen(o.boolean() ? t.left: t.right, e, n)
                },
                match: function(t, e, n) {
                    e = "";
                    for (var r = 0; r < t.body.length; r++) e += this.gen(t.body[r], e, n);
                    return e
                },
                "capture-group": function(t, e, n) {
                    return e = this.gen(t.body, e, n),
                    n[n.guid++] = e,
                    e
                },
                "non-capture-group": function(t, e, n) {
                    return this.gen(t.body, e, n)
                },
                "positive-lookahead": function(t, e, n) {
                    return this.gen(t.body, e, n)
                },
                "negative-lookahead": function(t, e, n) {
                    return ""
                },
                quantified: function(t, e, n) {
                    e = "";
                    for (var r = this.quantifier(t.quantifier), a = 0; r > a; a++) e += this.gen(t.body, e, n);
                    return e
                },
                quantifier: function(t, e, n) {
                    var r = Math.max(t.min, 0),
                    a = isFinite(t.max) ? t.max: r + o.integer(3, 7);
                    return o.integer(r, a)
                },
                charset: function(t, e, n) {
                    if (t.invert) return this["invert-charset"](t, e, n);
                    var r = o.pick(t.body);
                    return this.gen(r, e, n)
                },
                "invert-charset": function(t, e, n) {
                    for (var r, a = h,
                    i = 0; i < t.body.length; i++) switch ((r = t.body[i]).type) {
                    case "literal":
                        a = a.replace(r.body, "");
                        break;
                    case "range":
                        for (var u = this.gen(r.start, e, n).charCodeAt(), l = this.gen(r.end, e, n).charCodeAt(), s = u; l >= s; s++) a = a.replace(String.fromCharCode(s), "");
                    default:
                        var c = f[r.text];
                        if (c) for (var p = 0; p <= c.length; p++) a = a.replace(c[p], "")
                    }
                    return o.pick(a.split(""))
                },
                range: function(t, e, n) {
                    var r = this.gen(t.start, e, n).charCodeAt(),
                    a = this.gen(t.end, e, n).charCodeAt();
                    return String.fromCharCode(o.integer(r, a))
                },
                literal: function(t, e, n) {
                    return t.escaped ? t.body: t.text
                },
                unicode: function(t, e, n) {
                    return String.fromCharCode(parseInt(t.code, 16))
                },
                hex: function(t, e, n) {
                    return String.fromCharCode(parseInt(t.code, 16))
                },
                octal: function(t, e, n) {
                    return String.fromCharCode(parseInt(t.code, 8))
                },
                "back-reference": function(t, e, n) {
                    return n[t.code] || ""
                },
                CONTROL_CHARACTER_MAP: function() {
                    for (var t = "@ A B C D E F G H I J K L M N O P Q R S T U V W X Y Z [ \\ ] ^ _".split(" "), e = "\0        \b \t \n \v \f \r                  ".split(" "), n = {},
                    r = 0; r < t.length; r++) n[t[r]] = e[r];
                    return n
                } (),
                "control-character": function(t, e, n) {
                    return this.CONTROL_CHARACTER_MAP[t.code]
                }
            }),
            t.exports = i
        },
        function(t, e, n) {
            t.exports = n(24)
        },
        function(t, e, n) {
            var r = n(2),
            a = n(3),
            o = n(4);
            t.exports = function t(e, n, i) {
                i = i || [];
                var u = {
                    name: "string" == typeof n ? n.replace(r.RE_KEY, "$1") : n,
                    template: e,
                    type: a.type(e),
                    rule: o.parse(n)
                };
                switch (u.path = i.slice(0), u.path.push(void 0 === n ? "ROOT": u.name), u.type) {
                case "array":
                    u.items = [],
                    a.each(e,
                    function(e, n) {
                        u.items.push(t(e, n, u.path))
                    });
                    break;
                case "object":
                    u.properties = [],
                    a.each(e,
                    function(e, n) {
                        u.properties.push(t(e, n, u.path))
                    })
                }
                return u
            }
        },
        function(t, e, n) {
            t.exports = n(26)
        },
        function(t, e, n) {
            function r(t, e) {
                for (var n = i(t), r = u.diff(n, e), a = 0; a < r.length; a++);
                return r
            }
            var a = n(2),
            o = n(3),
            i = n(23),
            u = {
                diff: function(t, e, n) {
                    var r = [];
                    return this.name(t, e, n, r) && this.type(t, e, n, r) && (this.value(t, e, n, r), this.properties(t, e, n, r), this.items(t, e, n, r)),
                    r
                },
                name: function(t, e, n, r) {
                    var a = r.length;
                    return l.equal("name", t.path, n + "", t.name + "", r),
                    r.length === a
                },
                type: function(t, e, n, r) {
                    var i = r.length;
                    switch (t.type) {
                    case "string":
                        if (t.template.match(a.RE_PLACEHOLDER)) return ! 0;
                        break;
                    case "array":
                        if (t.rule.parameters) {
                            if (void 0 !== t.rule.min && void 0 === t.rule.max && 1 === t.rule.count) return ! 0;
                            if (t.rule.parameters[2]) return ! 0
                        }
                        break;
                    case "function":
                        return ! 0
                    }
                    return l.equal("type", t.path, o.type(e), t.type, r),
                    r.length === i
                },
                value: function(t, e, n, r) {
                    var o, i = r.length,
                    u = t.rule,
                    s = t.type;
                    if ("object" === s || "array" === s || "function" === s) return ! 0;
                    if (!u.parameters) {
                        switch (s) {
                        case "regexp":
                            return l.match("value", t.path, e, t.template, r),
                            r.length === i;
                        case "string":
                            if (t.template.match(a.RE_PLACEHOLDER)) return r.length === i
                        }
                        return l.equal("value", t.path, e, t.template, r),
                        r.length === i
                    }
                    switch (s) {
                    case "number":
                        var c = (e + "").split(".");
                        c[0] = +c[0],
                        void 0 !== u.min && void 0 !== u.max && (l.greaterThanOrEqualTo("value", t.path, c[0], Math.min(u.min, u.max), r), l.lessThanOrEqualTo("value", t.path, c[0], Math.max(u.min, u.max), r)),
                        void 0 !== u.min && void 0 === u.max && l.equal("value", t.path, c[0], u.min, r, "[value] " + n),
                        u.decimal && (void 0 !== u.dmin && void 0 !== u.dmax && (l.greaterThanOrEqualTo("value", t.path, c[1].length, u.dmin, r), l.lessThanOrEqualTo("value", t.path, c[1].length, u.dmax, r)), void 0 !== u.dmin && void 0 === u.dmax && l.equal("value", t.path, c[1].length, u.dmin, r));
                        break;
                    case "boolean":
                        break;
                    case "string":
                        o = (o = e.match(new RegExp(t.template, "g"))) ? o.length: 0,
                        void 0 !== u.min && void 0 !== u.max && (l.greaterThanOrEqualTo("repeat count", t.path, o, u.min, r), l.lessThanOrEqualTo("repeat count", t.path, o, u.max, r)),
                        void 0 !== u.min && void 0 === u.max && l.equal("repeat count", t.path, o, u.min, r);
                        break;
                    case "regexp":
                        o = (o = e.match(new RegExp(t.template.source.replace(/^\^|\$$/g, ""), "g"))) ? o.length: 0,
                        void 0 !== u.min && void 0 !== u.max && (l.greaterThanOrEqualTo("repeat count", t.path, o, u.min, r), l.lessThanOrEqualTo("repeat count", t.path, o, u.max, r)),
                        void 0 !== u.min && void 0 === u.max && l.equal("repeat count", t.path, o, u.min, r)
                    }
                    return r.length === i
                },
                properties: function(t, e, n, r) {
                    var a = r.length,
                    i = t.rule,
                    u = o.keys(e);
                    if (t.properties) {
                        if (t.rule.parameters ? (void 0 !== i.min && void 0 !== i.max && (l.greaterThanOrEqualTo("properties length", t.path, u.length, Math.min(i.min, i.max), r), l.lessThanOrEqualTo("properties length", t.path, u.length, Math.max(i.min, i.max), r)), void 0 !== i.min && void 0 === i.max && 1 !== i.count && l.equal("properties length", t.path, u.length, i.min, r)) : l.equal("properties length", t.path, u.length, t.properties.length, r), r.length !== a) return ! 1;
                        for (var s = 0; s < u.length; s++) r.push.apply(r, this.diff(function() {
                            var e;
                            return o.each(t.properties,
                            function(t) {
                                t.name === u[s] && (e = t)
                            }),
                            e || t.properties[s]
                        } (), e[u[s]], u[s]));
                        return r.length === a
                    }
                },
                items: function(t, e, n, r) {
                    var a = r.length;
                    if (t.items) {
                        var o = t.rule;
                        if (t.rule.parameters) {
                            if (void 0 !== o.min && void 0 !== o.max && (l.greaterThanOrEqualTo("items", t.path, e.length, Math.min(o.min, o.max) * t.items.length, r, "[{utype}] array is too short: {path} must have at least {expected} elements but instance has {actual} elements"), l.lessThanOrEqualTo("items", t.path, e.length, Math.max(o.min, o.max) * t.items.length, r, "[{utype}] array is too long: {path} must have at most {expected} elements but instance has {actual} elements")), void 0 !== o.min && void 0 === o.max) {
                                if (1 === o.count) return r.length === a;
                                l.equal("items length", t.path, e.length, o.min * t.items.length, r)
                            }
                            if (o.parameters[2]) return r.length === a
                        } else l.equal("items length", t.path, e.length, t.items.length, r);
                        if (r.length !== a) return ! 1;
                        for (var i = 0; i < e.length; i++) r.push.apply(r, this.diff(t.items[i % t.items.length], e[i], i % t.items.length));
                        return r.length === a
                    }
                }
            },
            l = {
                message: function(t) {
                    return (t.message || "[{utype}] Expect {path}'{ltype} {action} {expected}, but is {actual}").replace("{utype}", t.type.toUpperCase()).replace("{ltype}", t.type.toLowerCase()).replace("{path}", o.isArray(t.path) && t.path.join(".") || t.path).replace("{action}", t.action).replace("{expected}", t.expected).replace("{actual}", t.actual)
                },
                equal: function(t, e, n, r, a, o) {
                    if (n === r) return ! 0;
                    switch (t) {
                    case "type":
                        if ("regexp" === r && "string" === n) return ! 0
                    }
                    var i = {
                        path: e,
                        type: t,
                        actual: n,
                        expected: r,
                        action: "is equal to",
                        message: o
                    };
                    return i.message = l.message(i),
                    a.push(i),
                    !1
                },
                match: function(t, e, n, r, a, o) {
                    if (r.test(n)) return ! 0;
                    var i = {
                        path: e,
                        type: t,
                        actual: n,
                        expected: r,
                        action: "matches",
                        message: o
                    };
                    return i.message = l.message(i),
                    a.push(i),
                    !1
                },
                notEqual: function(t, e, n, r, a, o) {
                    if (n !== r) return ! 0;
                    var i = {
                        path: e,
                        type: t,
                        actual: n,
                        expected: r,
                        action: "is not equal to",
                        message: o
                    };
                    return i.message = l.message(i),
                    a.push(i),
                    !1
                },
                greaterThan: function(t, e, n, r, a, o) {
                    if (n > r) return ! 0;
                    var i = {
                        path: e,
                        type: t,
                        actual: n,
                        expected: r,
                        action: "is greater than",
                        message: o
                    };
                    return i.message = l.message(i),
                    a.push(i),
                    !1
                },
                lessThan: function(t, e, n, r, a, o) {
                    if (r > n) return ! 0;
                    var i = {
                        path: e,
                        type: t,
                        actual: n,
                        expected: r,
                        action: "is less to",
                        message: o
                    };
                    return i.message = l.message(i),
                    a.push(i),
                    !1
                },
                greaterThanOrEqualTo: function(t, e, n, r, a, o) {
                    if (n >= r) return ! 0;
                    var i = {
                        path: e,
                        type: t,
                        actual: n,
                        expected: r,
                        action: "is greater than or equal to",
                        message: o
                    };
                    return i.message = l.message(i),
                    a.push(i),
                    !1
                },
                lessThanOrEqualTo: function(t, e, n, r, a, o) {
                    if (r >= n) return ! 0;
                    var i = {
                        path: e,
                        type: t,
                        actual: n,
                        expected: r,
                        action: "is less than or equal to",
                        message: o
                    };
                    return i.message = l.message(i),
                    a.push(i),
                    !1
                }
            };
            r.Diff = u,
            r.Assert = l,
            t.exports = r
        },
        function(t, e, n) {
            t.exports = n(28)
        },
        function(t, e, n) {
            function r() {
                this.custom = {
                    events: {},
                    requestHeaders: {},
                    responseHeaders: {}
                }
            }
            var a = n(3);
            window._XMLHttpRequest = window.XMLHttpRequest,
            window._ActiveXObject = window.ActiveXObject;
            try {
                new window.Event("custom")
            } catch(t) {
                window.Event = function(t, e, n, r) {
                    var a = document.createEvent("CustomEvent");
                    return a.initCustomEvent(t, e, n, r),
                    a
                }
            }
            var o = {
                UNSENT: 0,
                OPENED: 1,
                HEADERS_RECEIVED: 2,
                LOADING: 3,
                DONE: 4
            },
            i = "readystatechange loadstart progress abort error load timeout loadend".split(" "),
            u = "timeout withCredentials".split(" "),
            l = "readyState responseURL status statusText responseType response responseText responseXML".split(" "),
            s = {
                100 : "Continue",
                101 : "Switching Protocols",
                200 : "OK",
                201 : "Created",
                202 : "Accepted",
                203 : "Non-Authoritative Information",
                204 : "No Content",
                205 : "Reset Content",
                206 : "Partial Content",
                300 : "Multiple Choice",
                301 : "Moved Permanently",
                302 : "Found",
                303 : "See Other",
                304 : "Not Modified",
                305 : "Use Proxy",
                307 : "Temporary Redirect",
                400 : "Bad Request",
                401 : "Unauthorized",
                402 : "Payment Required",
                403 : "Forbidden",
                404 : "Not Found",
                405 : "Method Not Allowed",
                406 : "Not Acceptable",
                407 : "Proxy Authentication Required",
                408 : "Request Timeout",
                409 : "Conflict",
                410 : "Gone",
                411 : "Length Required",
                412 : "Precondition Failed",
                413 : "Request Entity Too Large",
                414 : "Request-URI Too Long",
                415 : "Unsupported Media Type",
                416 : "Requested Range Not Satisfiable",
                417 : "Expectation Failed",
                422 : "Unprocessable Entity",
                500 : "Internal Server Error",
                501 : "Not Implemented",
                502 : "Bad Gateway",
                503 : "Service Unavailable",
                504 : "Gateway Timeout",
                505 : "HTTP Version Not Supported"
            };
            r._settings = {
                timeout: "10-100"
            },
            r.setup = function(t) {
                return a.extend(r._settings, t),
                r._settings
            },
            a.extend(r, o),
            a.extend(r.prototype, o),
            r.prototype.mock = !0,
            r.prototype.match = !1,
            a.extend(r.prototype, {
                open: function(t, e, n, o, s) {
                    function c(t) {
                        for (var e = 0; e < l.length; e++) try {
                            h[l[e]] = f[l[e]]
                        } catch(t) {}
                        h.dispatchEvent(new Event(t.type))
                    }
                    var h = this;
                    a.extend(this.custom, {
                        method: t,
                        url: e,
                        async: "boolean" != typeof n || n,
                        username: o,
                        password: s,
                        options: {
                            url: e,
                            type: t
                        }
                    }),
                    this.custom.timeout = function(t) {
                        if ("number" == typeof t) return t;
                        if ("string" == typeof t && !~t.indexOf("-")) return parseInt(t, 10);
                        if ("string" == typeof t && ~t.indexOf("-")) {
                            var e = t.split("-"),
                            n = parseInt(e[0], 10),
                            r = parseInt(e[1], 10);
                            return Math.round(Math.random() * (r - n)) + n
                        }
                    } (r._settings.timeout);
                    var p = function(t) {
                        function e(t, e) {
                            return "string" === a.type(t) ? t === e: "regexp" === a.type(t) ? t.test(e) : void 0
                        }
                        for (var n in r.Mock._mocked) {
                            var o = r.Mock._mocked[n];
                            if ((!o.rurl || e(o.rurl, t.url)) && (!o.rtype || e(o.rtype, t.type.toLowerCase()))) return o
                        }
                    } (this.custom.options);
                    if (p) this.match = !0,
                    this.custom.template = p,
                    this.readyState = r.OPENED,
                    this.dispatchEvent(new Event("readystatechange"));
                    else {
                        var f = function() {
                            function t() {
                                try {
                                    return new window._XMLHttpRequest
                                } catch(t) {}
                            }
                            var e, n, r = (e = location.href, n = /^([\w.+-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/.exec(e.toLowerCase()) || [], /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(n[1]));
                            return window.ActiveXObject ? !r && t() ||
                            function() {
                                try {
                                    return new window._ActiveXObject("Microsoft.XMLHTTP")
                                } catch(t) {}
                            } () : t()
                        } ();
                        this.custom.xhr = f;
                        for (var d = 0; d < i.length; d++) f.addEventListener(i[d], c);
                        o ? f.open(t, e, n, o, s) : f.open(t, e, n);
                        for (var m = 0; m < u.length; m++) try {
                            f[u[m]] = h[u[m]]
                        } catch(t) {}
                    }
                },
                setRequestHeader: function(t, e) {
                    if (this.match) {
                        var n = this.custom.requestHeaders;
                        n[t] ? n[t] += "," + e: n[t] = e
                    } else this.custom.xhr.setRequestHeader(t, e)
                },
                timeout: 0,
                withCredentials: !1,
                upload: {},
                send: function(t) {
                    function e() {
                        var t, e;
                        n.readyState = r.HEADERS_RECEIVED,
                        n.dispatchEvent(new Event("readystatechange")),
                        n.readyState = r.LOADING,
                        n.dispatchEvent(new Event("readystatechange")),
                        n.status = 200,
                        n.statusText = s[200],
                        n.response = n.responseText = JSON.stringify((t = n.custom.template, e = n.custom.options, a.isFunction(t.template) ? t.template(e) : r.Mock.mock(t.template)), null, 4),
                        n.readyState = r.DONE,
                        n.dispatchEvent(new Event("readystatechange")),
                        n.dispatchEvent(new Event("load")),
                        n.dispatchEvent(new Event("loadend"))
                    }
                    var n = this;
                    return this.custom.options.body = t,
                    this.match ? (this.setRequestHeader("X-Requested-With", "MockXMLHttpRequest"), this.dispatchEvent(new Event("loadstart")), void(this.custom.async ? setTimeout(e, this.custom.timeout) : e())) : void this.custom.xhr.send(t)
                },
                abort: function() {
                    return this.match ? (this.readyState = r.UNSENT, this.dispatchEvent(new Event("abort", !1, !1, this)), void this.dispatchEvent(new Event("error", !1, !1, this))) : void this.custom.xhr.abort()
                }
            }),
            a.extend(r.prototype, {
                responseURL: "",
                status: r.UNSENT,
                statusText: "",
                getResponseHeader: function(t) {
                    return this.match ? this.custom.responseHeaders[t.toLowerCase()] : this.custom.xhr.getResponseHeader(t)
                },
                getAllResponseHeaders: function() {
                    if (!this.match) return this.custom.xhr.getAllResponseHeaders();
                    var t = this.custom.responseHeaders,
                    e = "";
                    for (var n in t) t.hasOwnProperty(n) && (e += n + ": " + t[n] + "\r\n");
                    return e
                },
                overrideMimeType: function() {},
                responseType: "",
                response: null,
                responseText: "",
                responseXML: null
            }),
            a.extend(r.prototype, {
                addEventListener: function(t, e) {
                    var n = this.custom.events;
                    n[t] || (n[t] = []),
                    n[t].push(e)
                },
                removeEventListener: function(t, e) {
                    for (var n = this.custom.events[t] || [], r = 0; r < n.length; r++) n[r] === e && n.splice(r--, 1)
                },
                dispatchEvent: function(t) {
                    for (var e = this.custom.events[t.type] || [], n = 0; n < e.length; n++) e[n].call(this, t);
                    var r = "on" + t.type;
                    this[r] && this[r](t)
                }
            }),
            t.exports = r
        }])
    },
    "object" == (void 0 === exports ? "undefined": _typeof(exports)) && "object" == ("undefined" == typeof module ? "undefined": _typeof(module)) ? module.exports = qy() : "function" == typeof define && define.amd ? define([], qy) : "object" == (void 0 === exports ? "undefined": _typeof(exports)) ? exports.Mock = qy() : py.Mock = qy(),
    exports("mockjsbase", Mock)
});

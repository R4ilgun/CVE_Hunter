<?php
include("../../conn.php");
include("../../login_check.php");

if(isset($_GET['page'])){
	$page = $_GET['page'];
}else{
	$page = 1;
}
if(!is_numeric($page)){
	die('Not vaild page!');
}


$page_size = 11;
$start = $page_size * ($page - 1);


//count
$sql = "select * from cve_github order by push_time desc limit $start,$page_size;";
$result = mysqli_query($conn,$sql);


echo "<head><title>CVE Hunter</title></head>"; 
#echo "<center><h1>CVE SELECT</h1></center>";
echo '
<div class="layui-fluid">
  <div class="layui-row">
    <div class="layui-col-xs12">
      <div class="layui-card">
        <div class="layui-card-header">CVE SELECT</div>
        <div class="layui-card-body">
          Show CVE informaton from github.
        </div>
      </div>
';
echo '
<div class="layui-card">
<div class="layui-card-header">Show</div>
<div class="layui-card-body">
  <table class="layui-table">
    <colgroup>
      <col width="150">
      <col width="400">
      <col width="150">
      <col>
    </colgroup>
    <thead>
      <tr>
';

echo '
<th>CVE_id</th>
<th>CVE_description</th>
<th>CVE_author</th>
<th>CVE_push_time</th>
<th>CVE_operation</th>
</tr>
</thead>
<tbody>
';



while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td><center>" . $row['cve_name'] . "</center></td>";

$description = $row['cve_description'];
if(strlen($description) > 80){
    echo "<td>" . substr($row['cve_description'],0,80) . "...</td>";
}else{    
    echo "<td>" . $row['cve_description'] . "</td>";
}

#echo "<td>" . $row['cve_description'] . "</td>";
echo "<td><center>" . $row['cve_owner'] . "</center></td>";
echo "<td><center>" . $row['push_time'] . "</center></td>";
echo '<td><center><button class="layui-btn layui-btn-normal"><a href='.$row['cve_url'].' target="_blank">More</a></button>';
echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button class="layui-btn">Ohters</button></center></td>';
echo "</tr>";
}

echo '
</tbody>
</table>

';

$prev_page = $page - 1;
$next_page = $page + 1;

echo "		<center>
              <button class='layui-btn'><i class='layui-icon'><a href='http://cve.pwn4fun.com/admin/index.php#/cve/select?page=$prev_page'></i></button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <button class='layui-btn'><i class='layui-icon'><a href='http://cve.pwn4fun.com/admin/index.php#/cve/select?page=$next_page'></i></button>
            </center>
";


echo '
</div>
</div>
';



?>
